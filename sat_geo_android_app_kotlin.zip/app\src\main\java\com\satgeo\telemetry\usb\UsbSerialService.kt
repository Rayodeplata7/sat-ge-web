package com.satgeo.telemetry.usb

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.util.Log
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.*
import java.io.IOException

/**
 * SAT-GEO 4.0 - USB Serial OTG Hardware Driver (STM32F407 Discovery)
 * Reads USART2 continuous telemetry at 115200 baud (250 Hz sample rate).
 * Validates protocol packet: @,00,2,ADC_F,ADC_IR,XOR;\r\n
 */
class UsbSerialService(private val context: Context) {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var serialPort: UsbSerialPort? = null
    private var isReading = false
    private var ioJob: Job? = null

    private var onPacketReceivedListener: ((rawForce: Int, rawIR: Int) -> Unit)? = null
    private var onConnectionStateChangedListener: ((Boolean, String) -> Unit)? = null

    fun setOnPacketReceivedListener(listener: (Int, Int) -> Unit) {
        this.onPacketReceivedListener = listener
    }

    fun setOnConnectionStateChangedListener(listener: (Boolean, String) -> Unit) {
        this.onConnectionStateChangedListener = listener
    }

    fun connect(): Boolean {
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (availableDrivers.isEmpty()) {
            onConnectionStateChangedListener?.invoke(false, "No se detectó ningún dispositivo USB serial STM32.")
            return false
        }

        val driver = availableDrivers[0]
        val connection = usbManager.openDevice(driver.device)
        if (connection == null) {
            onConnectionStateChangedListener?.invoke(false, "Permiso USB denegado o no concedido.")
            return false
        }

        serialPort = driver.ports[0]
        try {
            serialPort?.open(connection)
            serialPort?.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            isReading = true

            startReadLoop()
            onConnectionStateChangedListener?.invoke(true, "STM32F407 Conectado a 115200 baudios.")
            return true
        } catch (e: IOException) {
            Log.e("SAT-GEO-USB", "Error al abrir puerto serial", e)
            disconnect()
            onConnectionStateChangedListener?.invoke(false, "Fallo al configurar puerto serial: ${e.message}")
            return false
        }
    }

    private fun startReadLoop() {
        ioJob = CoroutineScope(Dispatchers.IO).launch {
            val buffer = ByteArray(2048)
            val stringBuilder = StringBuilder()

            while (isReading && isActive) {
                try {
                    val len = serialPort?.read(buffer, 200) ?: 0
                    if (len > 0) {
                        val chunk = String(buffer, 0, len)
                        stringBuilder.append(chunk)

                        var newlineIdx = stringBuilder.indexOf("\n")
                        while (newlineIdx != -1) {
                            val line = stringBuilder.substring(0, newlineIdx).trim()
                            stringBuilder.delete(0, newlineIdx + 1)

                            parsePacket(line)
                            newlineIdx = stringBuilder.indexOf("\n")
                        }
                    }
                } catch (e: Exception) {
                    Log.w("SAT-GEO-USB", "Excepción en hilo de lectura USB: ${e.message}")
                    break
                }
            }
        }
    }

    private fun parsePacket(line: String) {
        // Trama esperada: @,00,2,ADC_F,ADC_IR,XOR;
        if (line.startsWith("@") && line.endsWith(";")) {
            val content = line.substring(1, line.length - 1)
            val tokens = content.split(",")
            if (tokens.size >= 5) {
                try {
                    val rf = tokens[3].toInt()
                    val rir = tokens[4].toInt()
                    val xorCheck = tokens[5].toInt()

                    // Verificación de Checksum XOR por hardware
                    if ((rf xor rir) == xorCheck) {
                        onPacketReceivedListener?.invoke(rf, rir)
                    }
                } catch (e: NumberFormatException) {
                    // Muestra corrupta o incompleta
                }
            }
        }
    }

    fun disconnect() {
        isReading = false
        ioJob?.cancel()
        try {
            serialPort?.close()
        } catch (e: IOException) {
            Log.e("SAT-GEO-USB", "Error al cerrar puerto", e)
        }
        serialPort = null
        onConnectionStateChangedListener?.invoke(false, "Desconectado.")
    }

    fun isConnected(): Boolean = isReading && serialPort != null
}
