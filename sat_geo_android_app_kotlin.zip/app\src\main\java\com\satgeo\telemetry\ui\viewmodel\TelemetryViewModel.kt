package com.satgeo.telemetry.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.satgeo.telemetry.engine.AlertLevel
import com.satgeo.telemetry.engine.GeomechanicalEngine
import com.satgeo.telemetry.engine.TelemetryRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.*

/**
 * SAT-GEO 4.0 - Architecture ViewModel
 * Coordinates telemetry data flow between hardware USB / simulation and UI.
 */
class TelemetryViewModel : ViewModel() {

    private val engine = GeomechanicalEngine()

    private val _telemetryState = MutableStateFlow<TelemetryRecord?>(null)
    val telemetryState: StateFlow<TelemetryRecord?> = _telemetryState.asStateFlow()

    private val _isHardwareConnected = MutableStateFlow(false)
    val isHardwareConnected: StateFlow<Boolean> = _isHardwareConnected.asStateFlow()

    private val _connectionStatus = MutableStateFlow("MODO SIMULACIÓN ACTIVA (250 Hz)")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private var simJob: Job? = null
    private var simTime = 0.0f
    private var simMode = "normal" // "normal", "rain", "seismic"

    init {
        startSimulation()
    }

    fun onHardwarePacket(rawForce: Int, rawIR: Int) {
        val record = engine.processSample(System.currentTimeMillis(), rawForce, rawIR)
        _telemetryState.value = record
    }

    fun setHardwareState(connected: Boolean, status: String) {
        _isHardwareConnected.value = connected
        _connectionStatus.value = status

        if (connected) {
            simJob?.cancel()
        } else {
            startSimulation()
        }
    }

    fun setSimulationScenario(mode: String) {
        this.simMode = mode
    }

    private fun startSimulation() {
        simJob?.cancel()
        simJob = viewModelScope.launch(Dispatchers.Default) {
            while (isActive && !_isHardwareConnected.value) {
                simTime += 0.004f // 4.0 ms tick = 250 Hz

                var f = 820f + sin(simTime * 2.2f) * 360f + (Math.random().toFloat() - 0.5f) * 40f
                var ir = 1050f + cos(simTime * 2.2f) * 250f + (Math.random().toFloat() - 0.5f) * 30f

                when (simMode) {
                    "rain" -> {
                        f += 1750f + sin(simTime * 3.8f) * 500f
                        ir += 1100f
                    }
                    "seismic" -> {
                        f += 2400f + (Math.random().toFloat() - 0.5f) * 1100f
                        ir += 1650f + (Math.random().toFloat() - 0.5f) * 600f
                    }
                }

                val rf = max(70, min(4095, f.toInt()))
                val rir = max(70, min(4095, ir.toInt()))

                val record = engine.processSample(System.currentTimeMillis(), rf, rir)
                _telemetryState.value = record

                delay(4) // 250 Hz sample rate
            }
        }
    }
}
