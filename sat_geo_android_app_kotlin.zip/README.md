# SAT-GEO 4.0 - Aplicación Móvil Nativa Android (Kotlin)
### Estación Táctica de Telemetría Geotécnica & Alerta Temprana en Tiempo Real

Esta aplicación móvil nativa fue desarrollada en **Kotlin** para Android, diseñada para conectarse directamente mediante un cable **USB OTG** al microcontrolador **STM32F407VG Discovery** a 115200 baudios y adquirir telemetría a **250 Hz exactos** (temporizador de hardware TIM2 cada 4.0 ms).

---

## 🚀 Arquitectura y Tecnologías Implementadas

1. **Driver USB Serial a Nivel de Kernel (`UsbSerialService.kt`):**
   - Basado en `usb-serial-for-android` (v3.8.0).
   - Acceso directo a `android.hardware.usb.UsbManager`.
   - Parsing continuo de tramas ASCII en hilos de fondo (`Dispatchers.IO`):
     `@,00,2,raw_force,raw_ir,xor_checksum;\r\n`
   - Validación matemática de checksum XOR byte a byte para descarte de tramas corruptas.

2. **Motor Físico Geomecánico (`GeomechanicalEngine.kt`):**
   - **Tekscan FlexiForce A201:** $F = 0.01467 \cdot (\text{ADC} - 65)\text{ N}$. Presión activa de empuje sobre el muro en kPa.
   - **Sharp GP2Y0A21YK0F:** Transducción óptica de desplazamiento milimétrico de la corona del muro.
   - **Criterio de Rotura Mohr-Coulomb:** Factor de Seguridad en tiempo real:
     $$FS = \frac{c' + (\sigma_n - u)\tan\phi'}{\tau_m}$$
   - **Modelo de Falla de Saito:** Predicción en tiempo real del Tiempo hasta el Colapso (TTF - *Time-To-Failure*) mediante aceleración de la velocidad de deformación terciaria ($\dot{\epsilon}$).

3. **Osciloscopio Gráfico de Ultra-Baja Latencia (`TelemetrySurfaceView.kt`):**
   - Implementado sobre un `SurfaceView` con doble búfer acelerado por hardware (`lockHardwareCanvas()`).
   - Renders a 60–120 FPS sin bloqueos ni pausas del recolector de basura (cero asignación dinámica de objetos en el bucle de dibujado).
   - Canales duales: Canal 1 (Tekscan en cian neón) y Canal 2 (Sharp IR en ámbar) con línea de trigger a 3.5 N.

4. **Sistema de Alarma Acústica y Háptica (`MainActivity.kt`):**
   - `ToneGenerator` (alarma de emergencia piezoeléctrica por audio nativo).
   - `Vibrator` / `VibrationEffect` con pulso de advertencia geomecánica cuando $FS < 1.0$.

5. **Modo Simulación Dinámica Autónomo:**
   - Si la tarjeta física STM32 no está enchufada, la aplicación arranca automáticamente un sintetizador geomecánico a 250 Hz exactos.
   - Botones interactivos para inyectar eventos severos de **Lluvia extrema (`🌧️`)** o **Sismo (`⚡`)**.

---

## 🛠️ Cómo Abrir y Compilar en Android Studio
1. Abre **Android Studio**.
2. Selecciona **File -> Open...** y elige la carpeta:
   `C:\Users\IDEAPAD\OneDrive\Documentos\SISTEMAS DIGITALES\sat_geo_android_app`
3. Deja que Gradle sincronice las dependencias automáticamente.
4. Conecta tu celular Android por cable USB con la **Depuración USB activada** (o usa un emulador).
5. Pulsa el botón verde **Run 'app' (Shift + F10)**.

¡El APK se compilará e instalará de inmediato en tu celular!
