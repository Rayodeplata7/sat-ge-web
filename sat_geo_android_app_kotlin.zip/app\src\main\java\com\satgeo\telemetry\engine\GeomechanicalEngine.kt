package com.satgeo.telemetry.engine

import kotlin.math.*

/**
 * SAT-GEO 4.0 - Geomechanical Physics & Predictive Failure Engine
 * Implements Mohr-Coulomb failure criteria, Tekscan A201 & Sharp IR calibration,
 * and Saito's creep curve Time-To-Failure (TTF) predictor.
 */
data class TelemetryRecord(
    val timestampMs: Long,
    val rawForce: Int,
    val rawIR: Int,
    val forceN: Float,
    val pressureKPa: Float,
    val distCm: Float,
    val dispMm: Float,
    val factorOfSafety: Float,
    val shearResistanceKPa: Float,
    val mobilizedShearKPa: Float,
    val velocityMmPerHr: Float,
    val ttfHours: Float?,
    val alertLevel: AlertLevel
)

enum class AlertLevel {
    STABLE,
    WARNING,
    CRITICAL
}

class GeomechanicalEngine {

    // Soil Mechanical Parameters (Default: Bogotá Cordillera Silty Sand)
    var cohesionKPa: Float = 18.5f
    var frictionAngleDeg: Float = 28.0f
    var unitWeightKNm3: Float = 19.2f
    var slopeHeightM: Float = 8.5f
    var slopeAngleDeg: Float = 45.0f
    var porePressureRatio: Float = 0.15f
    var surchargeKNm2: Float = 10.0f

    fun processSample(timestampMs: Long, rawForce: Int, rawIR: Int): TelemetryRecord {
        // 1. Tekscan FlexiForce A201 Calibration
        // F(N) = 0.01467 * (ADC_raw - 65)
        val forceN = if (rawForce > 65) {
            min(4.4f, 0.01467f * (rawForce - 65))
        } else {
            0.0f
        }
        val pressureKPa = forceN * 14.15f // Effective contact pressure on 9.53 mm sensing puck

        // 2. Sharp IR GP2Y0A21YK0F Optical Displacement
        // d(cm) = 5.0 - (ADC_raw / 4095) * 4.6
        val distCm = max(0.2f, 5.0f - (rawIR.toFloat() / 4095.0f) * 4.6f)
        val dispMm = max(0.0f, (5.0f - distCm) * 10.0f)

        // 3. Mohr-Coulomb Stability Factor
        val phiRad = Math.toRadians(frictionAngleDeg.toDouble()).toFloat()
        val betaRad = Math.toRadians(slopeAngleDeg.toDouble()).toFloat()

        val normalStress = (unitWeightKNm3 * slopeHeightM * cos(betaRad) * cos(betaRad)) + surchargeKNm2
        val porePressure = normalStress * porePressureRatio
        val effectiveNormalStress = max(0.0f, normalStress - porePressure)

        val shearResistance = cohesionKPa + (effectiveNormalStress * tan(phiRad))
        val mobilizedShear = (unitWeightKNm3 * slopeHeightM * sin(betaRad) * cos(betaRad)) + (pressureKPa * 0.45f)

        var fs = shearResistance / max(1.0f, mobilizedShear)
        if (fs < 0.3f) fs = 0.3f

        // 4. Saito Creep Velocity & Time To Failure (TTF)
        val velocityMmPerHr: Float
        val ttfHours: Float?

        val alertLevel = when {
            fs < 1.0f -> {
                velocityMmPerHr = 2.5f + (1.0f - fs) * 12.0f
                ttfHours = max(0.05f, 1.8f / velocityMmPerHr.pow(1.25f))
                AlertLevel.CRITICAL
            }
            fs < 1.35f -> {
                velocityMmPerHr = 0.08f * (1.5f / fs)
                ttfHours = null
                AlertLevel.WARNING
            }
            else -> {
                velocityMmPerHr = 0.002f
                ttfHours = null
                AlertLevel.STABLE
            }
        }

        return TelemetryRecord(
            timestampMs = timestampMs,
            rawForce = rawForce,
            rawIR = rawIR,
            forceN = forceN,
            pressureKPa = pressureKPa,
            distCm = distCm,
            dispMm = dispMm,
            factorOfSafety = fs,
            shearResistanceKPa = shearResistance,
            mobilizedShearKPa = mobilizedShear,
            velocityMmPerHr = velocityMmPerHr,
            ttfHours = ttfHours,
            alertLevel = alertLevel
        )
    }
}
