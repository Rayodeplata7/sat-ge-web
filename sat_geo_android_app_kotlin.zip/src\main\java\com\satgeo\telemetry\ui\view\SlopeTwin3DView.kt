package com.satgeo.telemetry.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.satgeo.telemetry.engine.AlertLevel
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class SlopeTwin3DView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var targetTiltDeg = 0f
    private var targetDispMm = 0f
    private var targetMoisturePct = 8f
    private var targetForceN = 0f
    private var targetPgaMg = 0f
    private var alertLevel = AlertLevel.STABLE

    // Smooth interpolated state for fluid 60 FPS animation
    private var dispTilt = 0f
    private var dispCrack = 0f
    private var dispMoisture = 8f
    private var dispForce = 0f
    private var dispPga = 0f

    private var yaw = -0.52f
    private var pitch = 0.36f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var pulse = 0f

    private val density = resources.displayMetrics.density

    private val rainDrops = Array(60) {
        floatArrayOf(Random.nextFloat() * 3f - 1.5f, Random.nextFloat() * 2.4f - 0.8f, Random.nextFloat() * 2f - 1f)
    }

    // Reusable paths (zero per-frame allocations)
    private val quadPath = Path()
    private val soilPath = Path()
    private val treePath = Path()
    private val crackPath = Path()
    private val waterPath = Path()
    private val hudRect = RectF()

    private val bgPaint = Paint()
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#182032"); strokeWidth = 2f }
    private val bedrockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#252B37") }
    private val soilFrontPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#664C3A") }
    private val grassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2B5B3F") }
    private val treeDarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1B432D") }
    private val treeLightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2A6846") }
    private val trunkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4A3525"); strokeWidth = 6f }
    private val waterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#880EA5E9") }
    private val wallFrontPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CBD5E1") }
    private val wallSidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#94A3B8") }
    private val wallTopPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E2E8F0") }
    private val mastPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#64748B"); strokeWidth = 5f }
    private val solarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E3A8A") }
    private val crackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#14090B") }
    private val crackRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F59E0B")
        style = Paint.Style.STROKE
        strokeWidth = 3.2f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val forceArrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#10B981")
        strokeWidth = 3.2f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val seismicRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F43F5E")
        style = Paint.Style.STROKE
        strokeWidth = 2.4f * density
    }
    private val beaconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#10B981") }
    private val beaconGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4410B981") }
    private val rainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#AA38BDF8")
        strokeWidth = 2.5f
        strokeCap = Paint.Cap.ROUND
    }
    private val hudBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CC070B14") }
    private val hudBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * density
    }
    private val hudTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 10.5f * density
        isFakeBoldText = true
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#94A3B8")
        textSize = 10f * density
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.parseColor("#0B1221"),
            Color.parseColor("#05070D"),
            Shader.TileMode.CLAMP
        )
    }

    fun updateTelemetry(
        tilt: Float,
        disp: Float,
        moisture: Float,
        forceN: Float,
        pgaMg: Float,
        level: AlertLevel
    ) {
        targetTiltDeg = tilt
        targetDispMm = disp
        targetMoisturePct = moisture
        targetForceN = forceN
        targetPgaMg = pgaMg
        alertLevel = level
        val c = when (level) {
            AlertLevel.CRITICAL -> Color.parseColor("#EF4444")
            AlertLevel.WARNING -> Color.parseColor("#F59E0B")
            AlertLevel.STABLE -> Color.parseColor("#10B981")
        }
        beaconPaint.color = c
        beaconGlowPaint.color = Color.argb(90, Color.red(c), Color.green(c), Color.blue(c))
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x; lastTouchY = event.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                yaw = (yaw + (event.x - lastTouchX) * 0.008f).coerceIn(-1.25f, 0.35f)
                pitch = (pitch + (event.y - lastTouchY) * 0.006f).coerceIn(0.15f, 0.95f)
                lastTouchX = event.x; lastTouchY = event.y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return super.onTouchEvent(event)
    }

    private fun p(x: Float, y: Float, z: Float, cx: Float, cy: Float, scale: Float): FloatArray {
        val cosY = cos(yaw); val sinY = sin(yaw)
        val x1 = x * cosY - z * sinY
        val z1 = x * sinY + z * cosY
        val cosP = cos(pitch); val sinP = sin(pitch)
        val y2 = y * cosP - z1 * sinP
        val z2 = y * sinP + z1 * cosP
        val persp = 5.2f / (5.2f + z2 * 0.42f)
        return floatArrayOf(cx + x1 * scale * persp, cy - y2 * scale * persp)
    }

    private fun quad(c: Canvas, a: FloatArray, b: FloatArray, d: FloatArray, e: FloatArray, paint: Paint) {
        quadPath.reset()
        quadPath.moveTo(a[0], a[1]); quadPath.lineTo(b[0], b[1]); quadPath.lineTo(d[0], d[1]); quadPath.lineTo(e[0], e[1]); quadPath.close()
        c.drawPath(quadPath, paint)
    }

    private fun drawTree(c: Canvas, x: Float, y: Float, z: Float, cx: Float, cy: Float, sc: Float) {
        val base = p(x, y, z, cx, cy, sc)
        val top = p(x, y + 0.35f, z, cx, cy, sc)
        c.drawLine(base[0], base[1], top[0], top[1], trunkPaint)
        val tip = p(x, y + 0.85f, z, cx, cy, sc)
        val l1 = p(x - 0.18f, y + 0.32f, z, cx, cy, sc)
        val r1 = p(x + 0.18f, y + 0.32f, z, cx, cy, sc)
        treePath.reset()
        treePath.moveTo(tip[0], tip[1]); treePath.lineTo(r1[0], r1[1]); treePath.lineTo(l1[0], l1[1]); treePath.close()
        c.drawPath(treePath, treeDarkPaint)
        val tip2 = p(x, y + 1.05f, z, cx, cy, sc)
        val l2 = p(x - 0.13f, y + 0.56f, z, cx, cy, sc)
        val r2 = p(x + 0.13f, y + 0.56f, z, cx, cy, sc)
        treePath.reset()
        treePath.moveTo(tip2[0], tip2[1]); treePath.lineTo(r2[0], r2[1]); treePath.lineTo(l2[0], l2[1]); treePath.close()
        c.drawPath(treePath, treeLightPaint)
    }

    private fun lerpColor(c1: Int, c2: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val r = (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * k).toInt()
        val g = (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * k).toInt()
        val b = (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * k).toInt()
        return Color.rgb(r, g, b)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        if (width <= 0 || height <= 0) return

        // Fast smooth interpolation (instant feel on micro-changes)
        dispTilt += (targetTiltDeg - dispTilt) * 0.28f
        dispCrack += (targetDispMm - dispCrack) * 0.28f
        dispMoisture += (targetMoisturePct - dispMoisture) * 0.22f
        dispForce += (targetForceN - dispForce) * 0.30f
        dispPga += (targetPgaMg - dispPga) * 0.32f
        pulse += 0.10f

        // Real-time ADXL345 seismic tremor camera shake
        val shakeAmp = if (dispPga > 8f) min(12f * density, (dispPga / 85f) * 6f * density) else 0f
        val shakeX = if (shakeAmp > 0f) sin(pulse * 19f) * shakeAmp else 0f
        val shakeY = if (shakeAmp > 0f) cos(pulse * 23f) * shakeAmp * 0.7f else 0f

        val cx = width * 0.50f + shakeX
        val cy = height * 0.60f + shakeY
        val sc = minOf(width, height) * 0.255f

        // Dynamic soil saturation darkening (dry terracotta -> dark saturated mud)
        val wetK = ((dispMoisture - 8f) / 92f).coerceIn(0f, 1f)
        soilFrontPaint.color = lerpColor(Color.parseColor("#6A4E3B"), Color.parseColor("#261B14"), wetK)

        // Base grid
        for (i in -2..2) {
            val a = p(i * 0.85f, -0.75f, -1.2f, cx, cy, sc)
            val b = p(i * 0.85f, -0.75f, 1.2f, cx, cy, sc)
            canvas.drawLine(a[0], a[1], b[0], b[1], gridPaint)
        }

        // Bedrock Base
        quad(canvas, p(-1.55f, -0.45f, 0.95f, cx, cy, sc), p(0.85f, -0.45f, 0.95f, cx, cy, sc),
            p(0.85f, -0.75f, 0.95f, cx, cy, sc), p(-1.55f, -0.75f, 0.95f, cx, cy, sc), bedrockPaint)

        // Soil Hillside Cross-section
        val fTL = p(-1.55f, 1.05f, 0.95f, cx, cy, sc)
        val fTM = p(-0.55f, 0.98f, 0.95f, cx, cy, sc)
        val fTR = p(0.42f, 0.55f, 0.95f, cx, cy, sc)
        val fBR = p(0.42f, -0.45f, 0.95f, cx, cy, sc)
        val fBL = p(-1.55f, -0.45f, 0.95f, cx, cy, sc)
        soilPath.reset()
        soilPath.moveTo(fTL[0], fTL[1]); soilPath.lineTo(fTM[0], fTM[1]); soilPath.lineTo(fTR[0], fTR[1])
        soilPath.lineTo(fBR[0], fBR[1]); soilPath.lineTo(fBL[0], fBL[1]); soilPath.close()
        canvas.drawPath(soilPath, soilFrontPaint)

        // Top vegetated crust
        val bTL = p(-1.55f, 1.05f, -0.95f, cx, cy, sc)
        val bTM = p(-0.55f, 0.98f, -0.95f, cx, cy, sc)
        val bTR = p(0.42f, 0.55f, -0.95f, cx, cy, sc)
        quad(canvas, bTL, bTM, fTM, fTL, grassPaint)
        quad(canvas, bTM, bTR, fTR, fTM, grassPaint)

        // Trees
        drawTree(canvas, -1.25f, 1.02f, -0.45f, cx, cy, sc)
        drawTree(canvas, -0.95f, 1.00f, 0.40f, cx, cy, sc)
        drawTree(canvas, -1.35f, 1.02f, 0.35f, cx, cy, sc)

        // Sensor 3 (HUMEDAD): Volumetric Water Table with live ripple crest
        val wh = -0.42f + (dispMoisture / 100f) * 0.96f
        val ripple = sin(pulse * 2.2f) * 0.025f * (0.3f + wetK)
        waterPaint.alpha = (85 + wetK * 120).toInt().coerceIn(85, 205)
        val wL = p(-1.53f, wh + ripple, 0.96f, cx, cy, sc)
        val wM = p(-0.55f, wh - ripple, 0.96f, cx, cy, sc)
        val wR = p(0.40f, wh + ripple * 0.8f, 0.96f, cx, cy, sc)
        val wBR = p(0.40f, -0.44f, 0.96f, cx, cy, sc)
        val wBL = p(-1.53f, -0.44f, 0.96f, cx, cy, sc)
        waterPath.reset()
        waterPath.moveTo(wL[0], wL[1]); waterPath.lineTo(wM[0], wM[1]); waterPath.lineTo(wR[0], wR[1])
        waterPath.lineTo(wBR[0], wBR[1]); waterPath.lineTo(wBL[0], wBL[1]); waterPath.close()
        canvas.drawPath(waterPath, waterPaint)

        // Sensor 1 (FSR) + Sensor 2 (IR) + Sensor 4 (ADXL): Reactive Retaining Wall
        val slide = (sqrt(dispCrack) * 0.085f + dispForce * 0.045f).coerceIn(0f, 0.44f)
        val tiltRad = (sqrt(dispTilt) * 0.14f + dispTilt * 0.032f + dispForce * 0.025f).coerceIn(0f, 0.54f)
        val wxB = 0.45f + slide
        val wxT = wxB + sin(tiltRad) * 1.18f

        // Tint wall with subtle thermal stress glow when FSR feels pressure
        val stressK = (dispForce / 2.2f).coerceIn(0f, 1f)
        wallFrontPaint.color = lerpColor(Color.parseColor("#CBD5E1"), Color.parseColor("#FCA5A5"), stressK * 0.65f)

        val wtFL = p(wxT, 0.72f, 0.95f, cx, cy, sc)
        val wtFR = p(wxT + 0.24f, 0.72f, 0.95f, cx, cy, sc)
        val wtBL = p(wxT, 0.72f, -0.95f, cx, cy, sc)
        val wtBR = p(wxT + 0.24f, 0.72f, -0.95f, cx, cy, sc)
        val wbFL = p(wxB, -0.45f, 0.95f, cx, cy, sc)
        val wbFR = p(wxB + 0.28f, -0.45f, 0.95f, cx, cy, sc)
        val wbBR = p(wxB + 0.28f, -0.45f, -0.95f, cx, cy, sc)

        quad(canvas, wtFR, wtBR, wbBR, wbFR, wallSidePaint)
        quad(canvas, wtFL, wtFR, wbFR, wbFL, wallFrontPaint)
        quad(canvas, wtBL, wtBR, wtFR, wtFL, wallTopPaint)

        // Sensor 1 (FSR-406): 3 Glowing 3D Force Stress Arrows pushing against the wall
        if (dispForce > 0.02f) {
            val arrowLen = (0.28f + dispForce * 0.22f).coerceIn(0.28f, 0.85f)
            val arrowCol = when {
                dispForce > 1.8f -> Color.parseColor("#EF4444")
                dispForce > 0.5f -> Color.parseColor("#F59E0B")
                else -> Color.parseColor("#10B981")
            }
            forceArrowPaint.color = arrowCol
            val zCoords = floatArrayOf(-0.55f, 0f, 0.55f)
            for (zPos in zCoords) {
                val yPos = 0.20f + sin(pulse * 2f + zPos) * 0.03f
                val tail = p(wxB - arrowLen - 0.12f, yPos, zPos, cx, cy, sc)
                val tip = p(wxB - 0.04f, yPos, zPos, cx, cy, sc)
                canvas.drawLine(tail[0], tail[1], tip[0], tip[1], forceArrowPaint)
                canvas.drawCircle(tip[0], tip[1], 4f * density, forceArrowPaint)
            }
        }

        // Sensor 2 (IR P/N 1102): Glowing 3D Opening Tension Crack on crown (activates at 0.05 mm!)
        if (dispCrack > 0.05f) {
            val gap = (0.04f + sqrt(dispCrack) * 0.055f).coerceIn(0.04f, 0.24f)
            val cBL = p(0.39f, 0.57f, -0.88f, cx, cy, sc)
            val cBR = p(0.39f + gap, 0.57f, -0.88f, cx, cy, sc)
            val cFR = p(0.39f + gap + slide * 0.45f, 0.57f, 0.88f, cx, cy, sc)
            val cFL = p(0.39f + slide * 0.2f, 0.57f, 0.88f, cx, cy, sc)
            crackPath.reset()
            crackPath.moveTo(cBL[0], cBL[1]); crackPath.lineTo(cBR[0], cBR[1])
            crackPath.lineTo(cFR[0], cFR[1]); crackPath.lineTo(cFL[0], cFL[1]); crackPath.close()
            canvas.drawPath(crackPath, crackFillPaint)
            crackRimPaint.color = if (dispCrack > 6f) Color.parseColor("#EF4444") else Color.parseColor("#F59E0B")
            canvas.drawLine(cBL[0], cBL[1], cFL[0], cFL[1], crackRimPaint)
            canvas.drawLine(cBR[0], cBR[1], cFR[0], cFR[1], crackRimPaint)
        }

        // IoT Solar Mast + Status Beacon
        val mBot = p(wxT + 0.12f, 0.72f, 0f, cx, cy, sc)
        val mTop = p(wxT + 0.12f, 1.24f, 0f, cx, cy, sc)
        canvas.drawLine(mBot[0], mBot[1], mTop[0], mTop[1], mastPaint)
        quad(canvas, p(wxT + 0.02f, 1.05f, -0.15f, cx, cy, sc), p(wxT + 0.26f, 0.98f, -0.15f, cx, cy, sc),
            p(wxT + 0.26f, 0.98f, 0.15f, cx, cy, sc), p(wxT + 0.02f, 1.05f, 0.15f, cx, cy, sc), solarPaint)

        // Sensor 4 (ADXL345): Expanding concentric seismic rings when vibration felt
        if (dispPga > 8f) {
            val ringR = (16f + ((pulse * 22f) % 48f)) * density
            seismicRingPaint.alpha = (220 - ((ringR / (64f * density)) * 200).toInt()).coerceIn(25, 220)
            canvas.drawCircle(mTop[0], mTop[1], ringR, seismicRingPaint)
        }

        val haloR = (16f + sin(pulse) * 4f) * density * 0.65f
        canvas.drawCircle(mTop[0], mTop[1], haloR, beaconGlowPaint)
        canvas.drawCircle(mTop[0], mTop[1], 7f * density, beaconPaint)

        // Rain particles starting as soon as soil moisture rises above dry baseline (>14%)
        if (dispMoisture > 14f) {
            val dropCount = ((dispMoisture - 12f) / 88f * rainDrops.size).toInt().coerceIn(8, rainDrops.size)
            for (i in 0 until dropCount) {
                val d = rainDrops[i]
                d[1] -= 0.09f
                if (d[1] < -0.7f) d[1] = 1.55f
                val a = p(d[0], d[1], d[2], cx, cy, sc)
                val b = p(d[0], d[1] - 0.16f, d[2], cx, cy, sc)
                canvas.drawLine(a[0], a[1], b[0], b[1], rainPaint)
            }
        }

        // Top 4-Sensor Live Activity HUD Pills (light up instantly when each sensor reacts)
        drawSensorPill(canvas, 10f * density, 10f * density, "FSR ${String.format("%.2f", dispForce)}N", dispForce > 0.02f, "#10B981")
        drawSensorPill(canvas, width * 0.50f + 4f * density, 10f * density, "IR ${String.format("%.1f", dispCrack)}mm", dispCrack > 0.05f, "#00F0FF")
        drawSensorPill(canvas, 10f * density, 34f * density, "HUM ${dispMoisture.toInt()}%", dispMoisture > 14f, "#38BDF8")
        drawSensorPill(canvas, width * 0.50f + 4f * density, 34f * density, "ADXL ${String.format("%.1f", dispTilt)}° · ${dispPga.toInt()}mg", dispTilt > 0.15f || dispPga > 8f, "#F59E0B")

        canvas.drawText("Desliza para rotar · 4 Sensores en Vivo", 12f * density, height - 10f * density, hintPaint)

        // Keep smooth 60 FPS animation alive while attached
        if (isAttachedToWindow) {
            postInvalidateOnAnimation()
        }
    }

    private fun drawSensorPill(c: Canvas, x: Float, y: Float, label: String, active: Boolean, hexColor: String) {
        val pillW = width * 0.46f
        val pillH = 20f * density
        hudRect.set(x, y, x + pillW, y + pillH)
        c.drawRoundRect(hudRect, 4f * density, 4f * density, hudBgPaint)
        hudBorderPaint.color = if (active) Color.parseColor(hexColor) else Color.parseColor("#243045")
        c.drawRoundRect(hudRect, 4f * density, 4f * density, hudBorderPaint)
        hudTextPaint.color = if (active) Color.parseColor(hexColor) else Color.parseColor("#94A3B8")
        c.drawText(label, x + 7f * density, y + 14f * density, hudTextPaint)
    }
}
