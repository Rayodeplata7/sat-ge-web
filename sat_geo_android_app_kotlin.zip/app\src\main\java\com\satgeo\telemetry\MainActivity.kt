package com.satgeo.telemetry

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.satgeo.telemetry.engine.AlertLevel
import com.satgeo.telemetry.ui.view.TelemetrySurfaceView
import com.satgeo.telemetry.ui.viewmodel.TelemetryViewModel
import com.satgeo.telemetry.usb.UsbSerialService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val viewModel: TelemetryViewModel by viewModels()
    private lateinit var usbSerialService: UsbSerialService

    // Audio & Haptics for Geotechnical Hazard Warning
    private var toneGenerator: ToneGenerator? = null
    private var vibrator: Vibrator? = null
    private var lastAlarmTime = 0L

    // UI Elements
    private lateinit var tvStatusConnection: TextView
    private lateinit var btnConnectUsb: Button
    private lateinit var cardFSSafety: LinearLayout
    private lateinit var tvFSValue: TextView
    private lateinit var tvAlarmLevel: TextView
    private lateinit var pbFSProgress: ProgressBar
    private lateinit var tvForceN: TextView
    private lateinit var tvPressureKPa: TextView
    private lateinit var tvDistCm: TextView
    private lateinit var tvDispMm: TextView
    private lateinit var oscilloscopeView: TelemetrySurfaceView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initHardwarePeripherals()
        initViews()
        initUsbService()
        observeViewModel()
    }

    private fun initHardwarePeripherals() {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 80)
            vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        } catch (e: Exception) {
            // Ignore if audio device is unavailable
        }
    }

    private fun initViews() {
        tvStatusConnection = findViewById(R.id.tvStatusConnection)
        btnConnectUsb = findViewById(R.id.btnConnectUsb)
        cardFSSafety = findViewById(R.id.cardFSSafety)
        tvFSValue = findViewById(R.id.tvFSValue)
        tvAlarmLevel = findViewById(R.id.tvAlarmLevel)
        pbFSProgress = findViewById(R.id.pbFSProgress)
        tvForceN = findViewById(R.id.tvForceN)
        tvPressureKPa = findViewById(R.id.tvPressureKPa)
        tvDistCm = findViewById(R.id.tvDistCm)
        tvDispMm = findViewById(R.id.tvDispMm)
        oscilloscopeView = findViewById(R.id.oscilloscopeView)

        btnConnectUsb.setOnClickListener {
            if (usbSerialService.isConnected()) {
                usbSerialService.disconnect()
            } else {
                val ok = usbSerialService.connect()
                if (!ok) {
                    Toast.makeText(this, "Conecta el cable USB OTG a la STM32F407", Toast.LENGTH_SHORT).show()
                }
            }
        }

        findViewById<Button>(R.id.btnSimRain).setOnClickListener {
            viewModel.setSimulationScenario("rain")
            Toast.makeText(this, "Simulando precipitación severa", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnSimSeismic).setOnClickListener {
            viewModel.setSimulationScenario("seismic")
            Toast.makeText(this, "Simulando evento sísmico", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnSimReset).setOnClickListener {
            viewModel.setSimulationScenario("normal")
            Toast.makeText(this, "Condición geotécnica normal restablecida", Toast.LENGTH_SHORT).show()
        }
    }

    private fun initUsbService() {
        usbSerialService = UsbSerialService(this)

        usbSerialService.setOnPacketReceivedListener { rawForce, rawIR ->
            viewModel.onHardwarePacket(rawForce, rawIR)
        }

        usbSerialService.setOnConnectionStateChangedListener { connected, status ->
            runOnUiThread {
                viewModel.setHardwareState(connected, status)
                btnConnectUsb.text = if (connected) "DESCONECTAR" else "USB STM32"
            }
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.connectionStatus.collectLatest { status ->
                tvStatusConnection.text = status
            }
        }

        lifecycleScope.launch {
            viewModel.telemetryState.collectLatest { record ->
                record ?: return@collectLatest

                // 1. Send data points to 250 Hz hardware canvas oscilloscope
                oscilloscopeView.pushSample(record.forceN, record.distCm)

                // 2. Update HUD values
                tvForceN.text = String.format("%.2f N", record.forceN)
                tvPressureKPa.text = String.format("%.1f kPa", record.pressureKPa)
                tvDistCm.text = String.format("%.2f cm", record.distCm)
                tvDispMm.text = String.format("Δ %.2f mm", record.dispMm)

                tvFSValue.text = String.format("%.2f", record.factorOfSafety)
                pbFSProgress.progress = (record.factorOfSafety * 100).toInt()

                // 3. Evaluate Geotechnical Hazard Level
                when (record.alertLevel) {
                    AlertLevel.CRITICAL -> {
                        tvAlarmLevel.text = "FALLA INMINENTE"
                        tvAlarmLevel.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.neon_crimson))
                        tvFSValue.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.neon_crimson))
                        cardFSSafety.setBackgroundResource(R.drawable.bg_hud_danger)
                        pbFSProgress.progressTintList = ContextCompat.getColorStateList(this@MainActivity, R.color.neon_crimson)

                        triggerHazardAlarm()
                    }
                    AlertLevel.WARNING -> {
                        tvAlarmLevel.text = "PRE-ALERTA"
                        tvAlarmLevel.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.neon_amber))
                        tvFSValue.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.neon_amber))
                        cardFSSafety.setBackgroundResource(R.drawable.bg_hud_card)
                        pbFSProgress.progressTintList = ContextCompat.getColorStateList(this@MainActivity, R.color.neon_amber)
                    }
                    AlertLevel.STABLE -> {
                        tvAlarmLevel.text = "ESTABLE"
                        tvAlarmLevel.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.neon_emerald))
                        tvFSValue.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.neon_emerald))
                        cardFSSafety.setBackgroundResource(R.drawable.bg_hud_card)
                        pbFSProgress.progressTintList = ContextCompat.getColorStateList(this@MainActivity, R.color.neon_emerald)
                    }
                }
            }
        }
    }

    private fun triggerHazardAlarm() {
        val now = System.currentTimeMillis()
        if (now - lastAlarmTime > 800) {
            lastAlarmTime = now
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 150)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(200)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        usbSerialService.disconnect()
        toneGenerator?.release()
    }
}
