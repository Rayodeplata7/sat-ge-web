package com.satgeo.telemetry.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.*
import java.io.IOException

/**
 * SAT-GEO 4.0 - USB Serial OTG Hardware Driver (ESP32 / CP2102 / CH340)
 * Reads continuous telemetry at 115200 baud (250 Hz sample rate).
 * Validates protocol packet: @,00,6,FSR,IR,SOIL,ACCX,ACCY,ACCZ,XOR;\r\n
 */
class UsbSerialService(private val context: Context) {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var serialPort: UsbSerialPort? = null
    private var isReading = false
    private var ioJob: Job? = null

    private var onPacketReceivedListener: ((rf: Int, rir: Int, rsoil: Int, ax: Int, ay: Int, az: Int) -> Unit)? = null
    private var onConnectionStateChangedListener: ((Boolean, String) -> Unit)? = null
    private var receiverRegistered = false

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_USB_PERMISSION -> {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    if (granted) connect()
                    else onConnectionStateChangedListener?.invoke(false, "Permiso USB denegado.")
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    disconnect()
                }
            }
        }
    }

    fun registerReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(ACTION_USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(context, usbReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true
    }

    fun unregisterReceiver() {
        if (!receiverRegistered) return
        try { context.unregisterReceiver(usbReceiver) } catch (_: Exception) {}
        receiverRegistered = false
    }

    fun hasConnectedDevice(): Boolean =
        UsbSerialProber.getDefaultProber().findAllDrivers(usbManager).isNotEmpty()

    companion object {
        private const val ACTION_USB_PERMISSION = "com.satgeo.telemetry.USB_PERMISSION"
    }

    fun setOnPacketReceivedListener(listener: (rf: Int, rir: Int, rsoil: Int, ax: Int, ay: Int, az: Int) -> Unit) {
        this.onPacketReceivedListener = listener
    }

    fun setOnConnectionStateChangedListener(listener: (Boolean, String) -> Unit) {
        this.onConnectionStateChangedListener = listener
    }

    fun connect(): Boolean {
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (availableDrivers.isEmpty()) {
            onConnectionStateChangedListener?.invoke(false, "No se detectó ningún dispositivo USB serial ESP32.")
            return false
        }

        val driver = availableDrivers[0]
        if (!usbManager.hasPermission(driver.device)) {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val permIntent = Intent(ACTION_USB_PERMISSION).setPackage(context.packageName)
            val pi = PendingIntent.getBroadcast(context, 0, permIntent, flags)
            usbManager.requestPermission(driver.device, pi)
            onConnectionStateChangedListener?.invoke(false, "Acepta el permiso USB en pantalla...")
            return false
        }
        val connection = usbManager.openDevice(driver.device)
        if (connection == null) {
            onConnectionStateChangedListener?.invoke(false, "Permiso USB denegado o puerto ocupado.")
            return false
        }

        serialPort = driver.ports[0]
        try {
            serialPort?.open(connection)
            serialPort?.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            try {
                serialPort?.dtr = false
                serialPort?.rts = false
            } catch (_: Exception) {}
            isReading = true

            startReadLoop()
            onConnectionStateChangedListener?.invoke(true, "ESP32 Conectado a 115200 baudios.")
            return true
        } catch (e: IOException) {
            Log.e("SAT-GEO-USB", "Error al abrir puerto serial", e)
            disconnect()
            onConnectionStateChangedListener?.invoke(false, "Fallo al configurar puerto serial: ${e.message}")
            return false
        }
    }

    private fun startReadLoop() {
        ioJob = CoroutineScope(Dispatchers.IO).launch {
            val buffer = ByteArray(2048)
            val stringBuilder = StringBuilder()

            while (isReading && isActive) {
                try {
                    val len = serialPort?.read(buffer, 200) ?: 0
                    if (len > 0) {
                        val chunk = String(buffer, 0, len)
                        stringBuilder.append(chunk)

                        var newlineIdx = stringBuilder.indexOf("\n")
                        while (newlineIdx != -1) {
                            val line = stringBuilder.substring(0, newlineIdx).trim()
                            stringBuilder.delete(0, newlineIdx + 1)

                            parsePacket(line)
                            newlineIdx = stringBuilder.indexOf("\n")
                        }
                    }
                } catch (e: Exception) {
                    Log.w("SAT-GEO-USB", "Excepción en hilo de lectura USB: ${e.message}")
                    if (isReading) {
                        withContext(Dispatchers.Main) {
                            disconnect()
                            onConnectionStateChangedListener?.invoke(false, "Cable USB desconectado.")
                        }
                    }
                    break
                }
            }
        }
    }

    private fun parsePacket(line: String) {
        if (line.startsWith("@") && line.endsWith(";")) {
            val content = line.substring(1, line.length - 1)
            val tokens = content.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            
            // Trama 6 Canales SAT-GEO ESP32: @,00,6,FSR,IR,SOIL,ACCX,ACCY,ACCZ,XOR;
            if (tokens.size >= 8 && tokens[0] == "00" && tokens[1] == "6") {
                try {
                    if (tokens.size >= 9) {
                        val payload = tokens.subList(0, 8).joinToString(",")
                        var calcXor = 0
                        for (ch in payload) calcXor = calcXor xor ch.code
                        val rxXor = tokens[8].toInt(16)
                        if (calcXor != rxXor) return
                    }
                    val rf = tokens[2].toInt()
                    val rir = tokens[3].toInt()
                    val rsoil = tokens[4].toInt()
                    val rax = tokens[5].toInt()
                    val ray = tokens[6].toInt()
                    val raz = tokens[7].toInt()
                    onPacketReceivedListener?.invoke(rf, rir, rsoil, rax, ray, raz)
                } catch (_: Exception) {
                    // Muestra descartada
                }
            } else if (tokens.size >= 4 && tokens[0] == "00") {
                try {
                    val rf = tokens[2].toInt()
                    val rir = tokens[3].toInt()
                    onPacketReceivedListener?.invoke(rf, rir, 3100, 30, -15, 256)
                } catch (_: Exception) {}
            } else if (tokens.size >= 2) {
                try {
                    val rf = tokens[0].toInt()
                    val rir = tokens[1].toInt()
                    onPacketReceivedListener?.invoke(rf, rir, 3100, 30, -15, 256)
                } catch (_: Exception) {}
            }
        }
    }

    fun disconnect() {
        isReading = false
        ioJob?.cancel()
        try {
            serialPort?.close()
        } catch (e: IOException) {
            Log.e("SAT-GEO-USB", "Error al cerrar puerto", e)
        }
        serialPort = null
        onConnectionStateChangedListener?.invoke(false, "Desconectado.")
    }

    fun isConnected(): Boolean = isReading && serialPort != null
}
