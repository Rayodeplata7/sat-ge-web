package com.satgeo.telemetry.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.satgeo.telemetry.engine.AlertLevel
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class SlopeTwin3DView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var tiltDeg = 0.22f
    private var dispMm = 0.8f
    private var moisturePct = 20f
    private var alertLevel = AlertLevel.STABLE

    private var yaw = -0.52f
    private var pitch = 0.36f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var pulse = 0f

    private val rainDrops = Array(55) {
        floatArrayOf(Random.nextFloat() * 3f - 1.5f, Random.nextFloat() * 2.4f - 0.8f, Random.nextFloat() * 2f - 1f)
    }

    private val bgPaint = Paint()
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#182032")
        strokeWidth = 2f
    }
    private val bedrockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#252B37") }
    private val soilFrontPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#574132") }
    private val soilSidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#423024") }
    private val grassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2B5B3F") }
    private val treeDarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1B432D") }
    private val treeLightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2A6846") }
    private val trunkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4A3525"); strokeWidth = 7f }
    private val waterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#7A0EA5E9") }
    private val wallFrontPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CBD5E1") }
    private val wallSidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#94A3B8") }
    private val wallTopPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E2E8F0") }
    private val mastPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#64748B"); strokeWidth = 5f }
    private val solarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E3A8A") }
    private val crackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F59E0B")
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val beaconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#10B981") }
    private val beaconGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4410B981") }
    private val rainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#AA38BDF8")
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#94A3B8")
        textSize = 24f
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.parseColor("#0B1221"),
            Color.parseColor("#05070D"),
            Shader.TileMode.CLAMP
        )
    }

    fun updateTelemetry(tilt: Float, disp: Float, moisture: Float, level: AlertLevel) {
        tiltDeg = tilt
        dispMm = disp
        moisturePct = moisture
        alertLevel = level
        val c = when (level) {
            AlertLevel.CRITICAL -> Color.parseColor("#EF4444")
            AlertLevel.WARNING -> Color.parseColor("#F59E0B")
            AlertLevel.STABLE -> Color.parseColor("#10B981")
        }
        beaconPaint.color = c
        beaconGlowPaint.color = Color.argb(85, Color.red(c), Color.green(c), Color.blue(c))
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x; lastTouchY = event.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                yaw = (yaw + (event.x - lastTouchX) * 0.008f).coerceIn(-1.25f, 0.35f)
                pitch = (pitch + (event.y - lastTouchY) * 0.006f).coerceIn(0.15f, 0.95f)
                lastTouchX = event.x; lastTouchY = event.y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return super.onTouchEvent(event)
    }

    private fun p(x: Float, y: Float, z: Float, cx: Float, cy: Float, scale: Float): FloatArray {
        val cosY = cos(yaw); val sinY = sin(yaw)
        val x1 = x * cosY - z * sinY
        val z1 = x * sinY + z * cosY
        val cosP = cos(pitch); val sinP = sin(pitch)
        val y2 = y * cosP - z1 * sinP
        val z2 = y * sinP + z1 * cosP
        val persp = 5.2f / (5.2f + z2 * 0.42f)
        return floatArrayOf(cx + x1 * scale * persp, cy - y2 * scale * persp)
    }

    private fun quad(c: Canvas, a: FloatArray, b: FloatArray, d: FloatArray, e: FloatArray, paint: Paint) {
        val path = Path().apply { moveTo(a[0], a[1]); lineTo(b[0], b[1]); lineTo(d[0], d[1]); lineTo(e[0], e[1]); close() }
        c.drawPath(path, paint)
    }

    private fun drawTree(c: Canvas, x: Float, y: Float, z: Float, cx: Float, cy: Float, sc: Float) {
        val base = p(x, y, z, cx, cy, sc)
        val top = p(x, y + 0.35f, z, cx, cy, sc)
        c.drawLine(base[0], base[1], top[0], top[1], trunkPaint)
        val tip = p(x, y + 0.85f, z, cx, cy, sc)
        val l1 = p(x - 0.18f, y + 0.32f, z, cx, cy, sc)
        val r1 = p(x + 0.18f, y + 0.32f, z, cx, cy, sc)
        val path1 = Path().apply { moveTo(tip[0], tip[1]); lineTo(r1[0], r1[1]); lineTo(l1[0], l1[1]); close() }
        c.drawPath(path1, treeDarkPaint)
        val tip2 = p(x, y + 1.05f, z, cx, cy, sc)
        val l2 = p(x - 0.13f, y + 0.56f, z, cx, cy, sc)
        val r2 = p(x + 0.13f, y + 0.56f, z, cx, cy, sc)
        val path2 = Path().apply { moveTo(tip2[0], tip2[1]); lineTo(r2[0], r2[1]); lineTo(l2[0], l2[1]); close() }
        c.drawPath(path2, treeLightPaint)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        if (width <= 0 || height <= 0) return

        val cx = width * 0.50f
        val cy = height * 0.58f
        val sc = minOf(width, height) * 0.27f

        // Base grid
        for (i in -2..2) {
            val a = p(i * 0.85f, -0.75f, -1.2f, cx, cy, sc)
            val b = p(i * 0.85f, -0.75f, 1.2f, cx, cy, sc)
            canvas.drawLine(a[0], a[1], b[0], b[1], gridPaint)
        }

        // Bedrock Base
        quad(canvas, p(-1.55f, -0.45f, 0.95f, cx, cy, sc), p(0.85f, -0.45f, 0.95f, cx, cy, sc),
            p(0.85f, -0.75f, 0.95f, cx, cy, sc), p(-1.55f, -0.75f, 0.95f, cx, cy, sc), bedrockPaint)

        // Soil Hillside Cross-section (front + top)
        val fTL = p(-1.55f, 1.05f, 0.95f, cx, cy, sc)
        val fTM = p(-0.55f, 0.98f, 0.95f, cx, cy, sc)
        val fTR = p(0.42f, 0.55f, 0.95f, cx, cy, sc)
        val fBR = p(0.42f, -0.45f, 0.95f, cx, cy, sc)
        val fBL = p(-1.55f, -0.45f, 0.95f, cx, cy, sc)
        val soilPath = Path().apply {
            moveTo(fTL[0], fTL[1]); lineTo(fTM[0], fTM[1]); lineTo(fTR[0], fTR[1])
            lineTo(fBR[0], fBR[1]); lineTo(fBL[0], fBL[1]); close()
        }
        canvas.drawPath(soilPath, soilFrontPaint)

        // Top vegetated crust
        val bTL = p(-1.55f, 1.05f, -0.95f, cx, cy, sc)
        val bTM = p(-0.55f, 0.98f, -0.95f, cx, cy, sc)
        val bTR = p(0.42f, 0.55f, -0.95f, cx, cy, sc)
        quad(canvas, bTL, bTM, fTM, fTL, grassPaint)
        quad(canvas, bTM, bTR, fTR, fTM, grassPaint)

        // Trees on upper plateau
        drawTree(canvas, -1.25f, 1.02f, -0.45f, cx, cy, sc)
        drawTree(canvas, -0.95f, 1.00f, 0.40f, cx, cy, sc)
        drawTree(canvas, -1.35f, 1.02f, 0.35f, cx, cy, sc)

        // Volumetric Water Table
        val wh = -0.42f + (moisturePct / 100f) * 0.92f
        quad(canvas, p(-1.53f, wh, 0.96f, cx, cy, sc), p(0.40f, wh, 0.96f, cx, cy, sc),
            p(0.40f, -0.44f, 0.96f, cx, cy, sc), p(-1.53f, -0.44f, 0.96f, cx, cy, sc), waterPaint)

        // Retaining Wall + Buttresses + Solar IoT Mast
        val slide = (dispMm * 0.012f).coerceIn(0f, 0.35f)
        val tilt = (tiltDeg * 0.022f).coerceIn(0f, 0.32f)
        val wxB = 0.45f + slide
        val wxT = wxB + sin(tilt) * 1.15f

        val wtFL = p(wxT, 0.72f, 0.95f, cx, cy, sc)
        val wtFR = p(wxT + 0.24f, 0.72f, 0.95f, cx, cy, sc)
        val wtBL = p(wxT, 0.72f, -0.95f, cx, cy, sc)
        val wtBR = p(wxT + 0.24f, 0.72f, -0.95f, cx, cy, sc)
        val wbFL = p(wxB, -0.45f, 0.95f, cx, cy, sc)
        val wbFR = p(wxB + 0.28f, -0.45f, 0.95f, cx, cy, sc)
        val wbBR = p(wxB + 0.28f, -0.45f, -0.95f, cx, cy, sc)

        quad(canvas, wtFR, wtBR, wbBR, wbFR, wallSidePaint)
        quad(canvas, wtFL, wtFR, wbFR, wbFL, wallFrontPaint)
        quad(canvas, wtBL, wtBR, wtFR, wtFL, wallTopPaint)

        // Tension crack
        if (dispMm > 1.2f) {
            crackPaint.alpha = ((dispMm / 10f) * 255).toInt().coerceIn(60, 255)
            val c1 = p(0.40f, 0.56f, -0.85f, cx, cy, sc)
            val c2 = p(0.40f + slide * 0.5f, 0.56f, 0.85f, cx, cy, sc)
            canvas.drawLine(c1[0], c1[1], c2[0], c2[1], crackPaint)
        }

        // IoT Solar Mast + Beacon
        val mBot = p(wxT + 0.12f, 0.72f, 0f, cx, cy, sc)
        val mTop = p(wxT + 0.12f, 1.22f, 0f, cx, cy, sc)
        canvas.drawLine(mBot[0], mBot[1], mTop[0], mTop[1], mastPaint)
        quad(canvas, p(wxT + 0.02f, 1.05f, -0.15f, cx, cy, sc), p(wxT + 0.26f, 0.98f, -0.15f, cx, cy, sc),
            p(wxT + 0.26f, 0.98f, 0.15f, cx, cy, sc), p(wxT + 0.02f, 1.05f, 0.15f, cx, cy, sc), solarPaint)

        pulse += 0.08f
        val haloR = 20f + sin(pulse) * 5f
        canvas.drawCircle(mTop[0], mTop[1], haloR, beaconGlowPaint)
        canvas.drawCircle(mTop[0], mTop[1], 10f, beaconPaint)

        // Rain particles
        if (moisturePct > 35f) {
            for (d in rainDrops) {
                d[1] -= 0.09f
                if (d[1] < -0.7f) d[1] = 1.55f
                val a = p(d[0], d[1], d[2], cx, cy, sc)
                val b = p(d[0], d[1] - 0.16f, d[2], cx, cy, sc)
                canvas.drawLine(a[0], a[1], b[0], b[1], rainPaint)
            }
            postInvalidateOnAnimation()
        }

        canvas.drawText("Desliza para rotar el modelo 3D", 28f, height - 20f, hintPaint)
    }
}
