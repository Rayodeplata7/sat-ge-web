package com.satgeo.telemetry.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.satgeo.telemetry.engine.AlertLevel
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class SlopeTwin3DView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var tiltDeg = 0.22f
    private var dispMm = 0.8f
    private var moisturePct = 20f
    private var alertLevel = AlertLevel.STABLE

    private var yaw = -0.55f
    private var pitch = 0.42f
    private var lastTouchX = 0f
    private var lastTouchY = 0f

    private val rainDrops = Array(45) { floatArrayOf(Random.nextFloat() * 2f - 1f, Random.nextFloat() * 2f - 1f, Random.nextFloat() * 2f - 1f) }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1D2333")
        strokeWidth = 2f
    }
    private val slopeTopPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2E4436")
        style = Paint.Style.FILL
    }
    private val slopeSidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F2F26")
        style = Paint.Style.FILL
    }
    private val waterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#770EA5E9")
        style = Paint.Style.FILL
    }
    private val wallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CBD5E1")
        style = Paint.Style.FILL
    }
    private val wallSidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#64748B")
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#475569")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val crackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F59E0B")
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val beaconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#10B981")
        style = Paint.Style.FILL
    }
    private val beaconGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4410B981")
        style = Paint.Style.FILL
    }
    private val rainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#AA38BDF8")
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#94A3B8")
        textSize = 26f
    }

    fun updateTelemetry(tilt: Float, disp: Float, moisture: Float, level: AlertLevel) {
        tiltDeg = tilt
        dispMm = disp
        moisturePct = moisture
        alertLevel = level
        val c = when (level) {
            AlertLevel.CRITICAL -> Color.parseColor("#EF4444")
            AlertLevel.WARNING -> Color.parseColor("#F59E0B")
            AlertLevel.STABLE -> Color.parseColor("#10B981")
        }
        beaconPaint.color = c
        beaconGlowPaint.color = Color.argb(75, Color.red(c), Color.green(c), Color.blue(c))
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastTouchX
                val dy = event.y - lastTouchY
                yaw += dx * 0.008f
                pitch = (pitch + dy * 0.006f).coerceIn(0.15f, 1.1f)
                lastTouchX = event.x
                lastTouchY = event.y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return super.onTouchEvent(event)
    }

    private fun project(x: Float, y: Float, z: Float, cx: Float, cy: Float, scale: Float): FloatArray {
        val cosY = cos(yaw)
        val sinY = sin(yaw)
        val x1 = x * cosY - z * sinY
        val z1 = x * sinY + z * cosY

        val cosP = cos(pitch)
        val sinP = sin(pitch)
        val y2 = y * cosP - z1 * sinP
        val z2 = y * sinP + z1 * cosP

        val perspective = 4.8f / (4.8f + z2 * 0.45f)
        return floatArrayOf(
            cx + x1 * scale * perspective,
            cy - y2 * scale * perspective
        )
    }

    private fun drawQuad(canvas: Canvas, p1: FloatArray, p2: FloatArray, p3: FloatArray, p4: FloatArray, fill: Paint) {
        val path = Path().apply {
            moveTo(p1[0], p1[1])
            lineTo(p2[0], p2[1])
            lineTo(p3[0], p3[1])
            lineTo(p4[0], p4[1])
            close()
        }
        canvas.drawPath(path, fill)
        canvas.drawPath(path, strokePaint)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.parseColor("#06080F"))
        if (width <= 0 || height <= 0) return

        val cx = width / 2f
        val cy = height * 0.54f
        val scale = minOf(width, height) * 0.24f

        // Base grid
        for (i in -2..2) {
            val a = project(i * 0.8f, -0.7f, -1.4f, cx, cy, scale)
            val b = project(i * 0.8f, -0.7f, 1.4f, cx, cy, scale)
            canvas.drawLine(a[0], a[1], b[0], b[1], gridPaint)
            val c = project(-1.6f, -0.7f, i * 0.7f, cx, cy, scale)
            val d = project(1.6f, -0.7f, i * 0.7f, cx, cy, scale)
            canvas.drawLine(c[0], c[1], d[0], d[1], gridPaint)
        }

        // Soil wedge (-1.5 .. 0.45)
        val sBackTopL = project(-1.5f, 0.95f, -0.95f, cx, cy, scale)
        val sBackTopR = project(0.45f, 0.55f, -0.95f, cx, cy, scale)
        val sFrontTopL = project(-1.5f, 0.95f, 0.95f, cx, cy, scale)
        val sFrontTopR = project(0.45f, 0.55f, 0.95f, cx, cy, scale)
        val sFrontBotL = project(-1.5f, -0.7f, 0.95f, cx, cy, scale)
        val sFrontBotR = project(0.45f, -0.7f, 0.95f, cx, cy, scale)
        val sBackBotR = project(0.45f, -0.7f, -0.95f, cx, cy, scale)

        drawQuad(canvas, sFrontTopL, sFrontTopR, sFrontBotR, sFrontBotL, slopeSidePaint)
        drawQuad(canvas, sBackTopL, sBackTopR, sFrontTopR, sFrontTopL, slopeTopPaint)

        // Water table rising inside slope
        val waterH = -0.65f + (moisturePct / 100f) * 1.15f
        val wFL = project(-1.48f, waterH, 0.96f, cx, cy, scale)
        val wFR = project(0.44f, waterH, 0.96f, cx, cy, scale)
        val wBL = project(-1.48f, -0.68f, 0.96f, cx, cy, scale)
        val wBR = project(0.44f, -0.68f, 0.96f, cx, cy, scale)
        drawQuad(canvas, wFL, wFR, wBR, wBL, waterPaint)

        // Retaining wall tilting and sliding
        val slideX = (dispMm * 0.014f).coerceIn(0f, 0.45f)
        val tiltRad = (tiltDeg * 0.025f).coerceIn(0f, 0.35f)
        val wxBase = 0.50f + slideX
        val wxTop = wxBase + sin(tiltRad) * 1.4f

        val wtFL = project(wxTop, 0.72f, 0.95f, cx, cy, scale)
        val wtFR = project(wxTop + 0.28f, 0.72f, 0.95f, cx, cy, scale)
        val wtBL = project(wxTop, 0.72f, -0.95f, cx, cy, scale)
        val wtBR = project(wxTop + 0.28f, 0.72f, -0.95f, cx, cy, scale)
        val wbFL = project(wxBase, -0.7f, 0.95f, cx, cy, scale)
        val wbFR = project(wxBase + 0.28f, -0.7f, 0.95f, cx, cy, scale)
        val wbBR = project(wxBase + 0.28f, -0.7f, -0.95f, cx, cy, scale)

        drawQuad(canvas, wtFR, wtBR, wbBR, wbFR, wallSidePaint)
        drawQuad(canvas, wtFL, wtFR, wbFR, wbFL, wallPaint)
        drawQuad(canvas, wtBL, wtBR, wtFR, wtFL, wallPaint)

        // Tension crack indicator
        if (dispMm > 1.2f) {
            crackPaint.alpha = ((dispMm / 12f) * 255).toInt().coerceIn(50, 255)
            val c1 = project(0.42f, 0.56f, -0.85f, cx, cy, scale)
            val c2 = project(0.42f + slideX * 0.5f, 0.56f, 0.85f, cx, cy, scale)
            canvas.drawLine(c1[0], c1[1], c2[0], c2[1], crackPaint)
        }

        // Beacon on top of wall
        val bPos = project(wxTop + 0.14f, 0.98f, 0f, cx, cy, scale)
        canvas.drawCircle(bPos[0], bPos[1], 22f, beaconGlowPaint)
        canvas.drawCircle(bPos[0], bPos[1], 11f, beaconPaint)

        // Rain animation when moisture > 35%
        if (moisturePct > 35f) {
            for (drop in rainDrops) {
                drop[1] -= 0.08f
                if (drop[1] < -0.7f) drop[1] = 1.4f
                val pTop = project(drop[0] * 1.4f, drop[1], drop[2], cx, cy, scale)
                val pBot = project(drop[0] * 1.4f, drop[1] - 0.14f, drop[2], cx, cy, scale)
                canvas.drawLine(pTop[0], pTop[1], pBot[0], pBot[1], rainPaint)
            }
            postInvalidateOnAnimation()
        }

        canvas.drawText("Desliza para rotar el modelo 3D", 28f, height - 24f, hintPaint)
    }
}
