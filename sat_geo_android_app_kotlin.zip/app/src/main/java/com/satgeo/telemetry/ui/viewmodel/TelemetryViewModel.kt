package com.satgeo.telemetry.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.satgeo.telemetry.engine.GeomechanicalEngine
import com.satgeo.telemetry.engine.TelemetryRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.cos
import kotlin.math.sin

class TelemetryViewModel : ViewModel() {

    private val engine = GeomechanicalEngine()

    private val _telemetryState = MutableStateFlow<TelemetryRecord?>(null)
    val telemetryState: StateFlow<TelemetryRecord?> = _telemetryState.asStateFlow()

    private val _isHardwareConnected = MutableStateFlow(false)
    val isHardwareConnected: StateFlow<Boolean> = _isHardwareConnected.asStateFlow()

    private val _isWifiConnected = MutableStateFlow(false)
    val isWifiConnected: StateFlow<Boolean> = _isWifiConnected.asStateFlow()

    private val _connectionStatus = MutableStateFlow("Modo Demostración · Sector K4+800")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private var simJob: Job? = null
    private var wifiJob: Job? = null
    private var simTime = 0.0f
    private var simMode = "normal"

    init {
        startSimulation()
    }

    fun onHardwarePacket(
        rawForce: Int,
        rawIR: Int,
        rawSoil: Int = 3250,
        accX: Int = 1,
        accY: Int = 0,
        accZ: Int = 256
    ) {
        val record = engine.processSample(
            System.currentTimeMillis(),
            rawForce,
            rawIR,
            rawSoil,
            accX,
            accY,
            accZ
        )
        _telemetryState.value = record
    }

    fun setHardwareState(connected: Boolean, status: String) {
        _isHardwareConnected.value = connected
        _connectionStatus.value = status
        if (connected) {
            simJob?.cancel()
            wifiJob?.cancel()
            _isWifiConnected.value = false
        } else if (!_isWifiConnected.value) {
            startSimulation()
        }
    }

    fun toggleWifi(ip: String = "192.168.4.1") {
        if (_isWifiConnected.value) {
            disconnectWifi()
            return
        }
        wifiJob?.cancel()
        simJob?.cancel()
        _isWifiConnected.value = true
        _connectionStatus.value = "Conectando Wi-Fi ($ip)..."

        wifiJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive && _isWifiConnected.value) {
                try {
                    val conn = (URL("http://$ip/api/telemetry").openConnection() as HttpURLConnection).apply {
                        connectTimeout = 1500
                        readTimeout = 1500
                        requestMethod = "GET"
                    }
                    if (conn.responseCode == 200) {
                        val body = conn.inputStream.bufferedReader().use { it.readText() }
                        val json = JSONObject(body)
                        _connectionStatus.value = "Wi-Fi ESP32 · $ip"
                        onHardwarePacket(
                            json.optInt("raw_fsr", 78),
                            json.optInt("raw_ir", 120),
                            json.optInt("raw_soil", 3250),
                            json.optInt("acc_x", 1),
                            json.optInt("acc_y", 0),
                            json.optInt("acc_z", 256)
                        )
                    } else {
                        _connectionStatus.value = "Sin respuesta HTTP de $ip"
                    }
                    conn.disconnect()
                } catch (_: Exception) {
                    _connectionStatus.value = "Buscando ESP32 en $ip..."
                }
                delay(150)
            }
        }
    }

    fun disconnectWifi() {
        _isWifiConnected.value = false
        wifiJob?.cancel()
        if (!_isHardwareConnected.value) {
            _connectionStatus.value = "Modo Demostración · Sector K4+800"
            startSimulation()
        }
    }

    fun setSimulationScenario(mode: String) {
        this.simMode = mode
    }

    private fun startSimulation() {
        simJob?.cancel()
        simJob = viewModelScope.launch(Dispatchers.Default) {
            while (isActive && !_isHardwareConnected.value && !_isWifiConnected.value) {
                simTime += 0.05f
                var f = 78f + sin(simTime) * 2f
                var ir = 120f + cos(simTime) * 5f
                var soil = 3250f
                var ax = 1f
                var ay = 0f
                var az = 256f

                when (simMode) {
                    "rain" -> {
                        f = 255f + sin(simTime * 2f) * 15f
                        ir = 1550f + sin(simTime) * 120f
                        soil = 1350f
                        ax = 26f
                        ay = 10f
                        az = 254f
                    }
                    "seismic" -> {
                        f = 350f + sin(simTime * 6f) * 35f
                        ir = 2800f + cos(simTime * 4f) * 200f
                        soil = 1250f
                        ax = sin(simTime * 12f) * 55f
                        ay = cos(simTime * 10f) * 35f
                        az = 256f + sin(simTime * 15f) * 45f
                    }
                }
                onHardwarePacket(f.toInt(), ir.toInt(), soil.toInt(), ax.toInt(), ay.toInt(), az.toInt())
                delay(50)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        simJob?.cancel()
        wifiJob?.cancel()
    }
}
