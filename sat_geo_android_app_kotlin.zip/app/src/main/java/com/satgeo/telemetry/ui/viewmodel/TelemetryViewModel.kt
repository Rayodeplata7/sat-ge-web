package com.satgeo.telemetry.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.satgeo.telemetry.engine.GeomechanicalEngine
import com.satgeo.telemetry.engine.TelemetryRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.cos
import kotlin.math.sin

class TelemetryViewModel : ViewModel() {

    private val engine = GeomechanicalEngine()

    private val _telemetryState = MutableStateFlow<TelemetryRecord?>(null)
    val telemetryState: StateFlow<TelemetryRecord?> = _telemetryState.asStateFlow()

    private val _isHardwareConnected = MutableStateFlow(false)
    val isHardwareConnected: StateFlow<Boolean> = _isHardwareConnected.asStateFlow()

    private val _isHttpConnected = MutableStateFlow(false)
    val isHttpConnected: StateFlow<Boolean> = _isHttpConnected.asStateFlow()

    private val _connectionStatus = MutableStateFlow("Esperando Sensores Reales (USB / Wi-Fi)")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private var simJob: Job? = null
    private var httpJob: Job? = null
    private var simTime = 0.0f
    private var simMode = "normal"
    private var rainPercent = 0

    // Hardware-first: no inicia simulación falsa al abrir la app
    fun calibrateZero() {
        engine.calibrateZero()
    }

    fun startTestSimulation() {
        if (_isHardwareConnected.value || _isHttpConnected.value) return
        engine.resetZero()
        _connectionStatus.value = "Modo Prueba (Sin Sensores)"
        startSimulation()
    }

    fun onHardwarePacket(
        rawForce: Int,
        rawIR: Int,
        rawSoil: Int = 3250,
        accX: Int = 1,
        accY: Int = 0,
        accZ: Int = 256
    ) {
        val record = engine.processSample(
            System.currentTimeMillis(),
            rawForce,
            rawIR,
            rawSoil,
            accX,
            accY,
            accZ
        )
        _telemetryState.value = record
    }

    fun setHardwareState(connected: Boolean, status: String) {
        _isHardwareConnected.value = connected
        _connectionStatus.value = status
        if (connected) {
            simJob?.cancel()
            httpJob?.cancel()
            _isHttpConnected.value = false
        } else if (!_isHttpConnected.value) {
            _connectionStatus.value = "Esperando Sensores Reales (USB / Wi-Fi)"
        }
    }

    fun connectHttpEndpoint(baseUrl: String, label: String) {
        httpJob?.cancel()
        simJob?.cancel()
        _isHttpConnected.value = true
        _connectionStatus.value = "Conectando a $label..."

        val cleanUrl = baseUrl.trim().removeSuffix("/")
        val target = if (cleanUrl.startsWith("http")) "$cleanUrl/api/telemetry" else "http://$cleanUrl/api/telemetry"

        httpJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive && _isHttpConnected.value) {
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL(target).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 1500
                        readTimeout = 1500
                        requestMethod = "GET"
                    }
                    if (conn.responseCode == 200) {
                        val body = conn.inputStream.bufferedReader().use { it.readText() }
                        val json = JSONObject(body)
                        _connectionStatus.value = "$label · En Línea"
                        onHardwarePacket(
                            json.optInt("raw_fsr", 78),
                            json.optInt("raw_ir", 120),
                            json.optInt("raw_soil", 3250),
                            json.optInt("acc_x", 1),
                            json.optInt("acc_y", 0),
                            json.optInt("acc_z", 256)
                        )
                    } else {
                        _connectionStatus.value = "Sin respuesta de $label"
                    }
                } catch (_: Exception) {
                    _connectionStatus.value = "Buscando $label..."
                } finally {
                    try { conn?.disconnect() } catch (_: Exception) {}
                }
                delay(120)
            }
        }
    }

    fun disconnectHttp() {
        _isHttpConnected.value = false
        httpJob?.cancel()
        if (!_isHardwareConnected.value) {
            _connectionStatus.value = "Esperando Sensores Reales (USB / Wi-Fi)"
        }
    }

    fun setRainLevel(percent: Int) {
        rainPercent = percent.coerceIn(0, 100)
        simMode = "normal"
        startTestSimulation()
    }

    fun setSimulationScenario(mode: String) {
        this.simMode = mode
        this.rainPercent = when (mode) {
            "rain" -> 80
            "seismic" -> 95
            else -> 0
        }
        startTestSimulation()
    }

    private fun startSimulation() {
        simJob?.cancel()
        simJob = viewModelScope.launch(Dispatchers.Default) {
            while (isActive && !_isHardwareConnected.value && !_isHttpConnected.value) {
                simTime += 0.06f
                val r = rainPercent / 100f
                var f = 78f + r * 220f + sin(simTime) * 3f
                var ir = 120f + r * 1800f + cos(simTime) * 8f
                var soil = 3250f - r * 2050f
                var ax = 1f + r * 35f
                var ay = r * 14f
                var az = 256f

                if (simMode == "seismic") {
                    f = 350f + sin(simTime * 7f) * 35f
                    ir = 2800f + cos(simTime * 5f) * 180f
                    soil = 1250f
                    ax = sin(simTime * 14f) * 55f
                    ay = cos(simTime * 12f) * 35f
                    az = 256f + sin(simTime * 18f) * 45f
                }

                onHardwarePacket(f.toInt(), ir.toInt(), soil.toInt(), ax.toInt(), ay.toInt(), az.toInt())
                delay(60)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        simJob?.cancel()
        httpJob?.cancel()
    }
}
