package com.satgeo.telemetry.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class StabilityGaugeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var targetFs = 1.55f
    private var currentFs = 1.55f
    private var arcColor = Color.parseColor("#10B981")

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 18f
        color = Color.parseColor("#1E2436")
        strokeCap = Paint.Cap.ROUND
    }

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 18f
        strokeCap = Paint.Cap.ROUND
    }

    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#94A3B8")
        textAlign = Paint.Align.CENTER
    }

    private val rect = RectF()

    fun setFactorOfSafety(fs: Float) {
        targetFs = fs.coerceIn(0.4f, 2.4f)
        arcColor = when {
            targetFs < 1.0f -> Color.parseColor("#EF4444")
            targetFs < 1.35f -> Color.parseColor("#F59E0B")
            else -> Color.parseColor("#10B981")
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = minOf(width, height).toFloat()
        val pad = 22f
        rect.set(
            (width - size) / 2f + pad,
            (height - size) / 2f + pad,
            (width + size) / 2f - pad,
            (height + size) / 2f - pad
        )

        currentFs += (targetFs - currentFs) * 0.25f
        val sweep = ((currentFs / 2.2f).coerceIn(0.06f, 1.0f)) * 270f

        canvas.drawArc(rect, 135f, 270f, false, trackPaint)
        arcPaint.color = arcColor
        canvas.drawArc(rect, 135f, sweep, false, arcPaint)

        valuePaint.textSize = size * 0.25f
        labelPaint.textSize = size * 0.10f
        canvas.drawText(String.format("%.2f", currentFs), width / 2f, height / 2f + valuePaint.textSize * 0.28f, valuePaint)
        canvas.drawText("FACTOR FS", width / 2f, height / 2f + valuePaint.textSize * 0.75f, labelPaint)

        if (kotlin.math.abs(targetFs - currentFs) > 0.005f) {
            postInvalidateOnAnimation()
        }
    }
}
