package com.satgeo.telemetry.engine

import kotlin.math.*

/**
 * HELIOS-9 // GEO-LATTICE 4.0 PRO - Motor Geotécnico Acoplado (ESP32 Multi-Sensorial)
 * Modela:
 *   - FSR-406 (Presión y Empuje Activo de Tierras)
 *   - IR P/N 1102 (Desplazamiento y Apertura de Grieta Coronal)
 *   - Sonda Higrométrica LM393 (Saturación Hidráulica W% y Presión de Poros)
 *   - ADXL345 (Inclinometría Triaxial θx, θy y Aceleración Sísmica PGA)
 *   - Criterio de Rotura Mohr-Coulomb Dinámico y Ley de Fluencia de Saito
 */
data class TelemetryRecord(
    val timestampMs: Long,
    val rawForce: Int,
    val rawIR: Int,
    val rawSoil: Int,
    val accX: Int,
    val accY: Int,
    val accZ: Int,
    val forceN: Float,
    val pressureKPa: Float,
    val momentNm: Float,
    val distCm: Float,
    val dispMm: Float,
    val soilMoisturePct: Float,
    val tiltDeg: Float,
    val tiltX: Float,
    val tiltY: Float,
    val pgaMg: Float,
    val factorOfSafety: Float,
    val shearResistanceKPa: Float,
    val mobilizedShearKPa: Float,
    val velocityMmPerHr: Float,
    val ttfHours: Float?,
    val alertLevel: AlertLevel
)

enum class AlertLevel {
    STABLE,
    WARNING,
    CRITICAL
}

class GeomechanicalEngine {

    // Parámetros Geotécnicos del Suelo (Valores por defecto Cordillera Oriental Bogotá)
    var cohesionKPa: Float = 18.5f
    var frictionAngleDeg: Float = 28.0f
    var unitWeightKNm3: Float = 19.2f
    var slopeHeightM: Float = 8.5f
    var slopeAngleDeg: Float = 45.0f
    var basePorePressureRatio: Float = 0.15f
    var surchargeKNm2: Float = 10.0f

    fun processSample(
        timestampMs: Long,
        rawForce: Int,
        rawIR: Int,
        rawSoil: Int = 3100,
        rawAccX: Int = 30,
        rawAccY: Int = -15,
        rawAccZ: Int = 256
    ): TelemetryRecord {
        // 1. FSR-406 (Empuje Activo N y Presión Lateral kPa)
        val forceN = if (rawForce > 65) {
            min(4.4f, 0.01467f * (rawForce - 65))
        } else {
            0.0f
        }
        val pressureKPa = forceN * 14.15f
        val momentNm = forceN * (slopeHeightM / 3.0f) * 0.44f

        // 2. IR Reflectivo P/N 1102 (Desplazamiento Coronal)
        val distCm = max(0.2f, 5.0f - (rawIR.toFloat() / 4095.0f) * 4.6f)
        val dispMm = max(0.0f, (5.0f - distCm) * 10.0f)

        // 3. Sonda Higrométrica Suelo LM393 (Humedad W%)
        val soilMoisturePct = max(5.0f, min(100.0f, ((3800.0f - rawSoil.toFloat()) / 2600.0f) * 100.0f))

        // 4. ADXL345 (Inclinometría Triaxial y Aceleración Sísmica)
        val ax_g = rawAccX.toFloat() / 256.0f
        val ay_g = rawAccY.toFloat() / 256.0f
        val az_g = rawAccZ.toFloat() / 256.0f
        val tiltX = Math.toDegrees(atan2(ax_g.toDouble(), sqrt((ay_g * ay_g + az_g * az_g).toDouble()))).toFloat()
        val tiltY = Math.toDegrees(atan2(ay_g.toDouble(), sqrt((ax_g * ax_g + az_g * az_g).toDouble()))).toFloat()
        val tiltDeg = sqrt(tiltX * tiltX + tiltY * tiltY)
        val pgaMg = abs(sqrt(ax_g * ax_g + ay_g * ay_g + az_g * az_g) - 1.0f) * 1000.0f

        // 5. Criterio de Rotura Mohr-Coulomb Acoplado Dinámico
        val phiRad = Math.toRadians(frictionAngleDeg.toDouble()).toFloat()
        val betaRad = Math.toRadians(slopeAngleDeg.toDouble()).toFloat()

        // Pérdida de cohesión por saturación de agua (lluvia)
        val effectiveCohesion = max(2.0f, cohesionKPa * (1.0f - (soilMoisturePct / 100.0f) * 0.55f))
        val dynamicPoreRatio = max(basePorePressureRatio, (soilMoisturePct / 100.0f) * 0.45f)

        val normalStress = (unitWeightKNm3 * slopeHeightM * cos(betaRad) * cos(betaRad)) + surchargeKNm2
        val porePressure = normalStress * dynamicPoreRatio
        val effectiveNormalStress = max(0.0f, normalStress - porePressure)

        val shearResistance = effectiveCohesion + (effectiveNormalStress * tan(phiRad))
        val lateralThrustKPa = pressureKPa
        val seismicLoadKPa = (pgaMg / 1000.0f) * unitWeightKNm3 * slopeHeightM * 0.35f
        val mobilizedShear = (unitWeightKNm3 * slopeHeightM * sin(betaRad) * cos(betaRad)) + (lateralThrustKPa * 0.45f) + seismicLoadKPa

        var fs = shearResistance / max(1.0f, mobilizedShear)
        if (fs < 0.3f) fs = 0.3f

        // 6. Ley de Fluencia de Saito (Creep Velocity & TTF)
        val velocityMmPerHr: Float
        val ttfHours: Float?

        val alertLevel = when {
            fs < 1.0f -> {
                velocityMmPerHr = 2.5f + (1.0f - fs) * 12.0f
                ttfHours = max(0.05f, 1.8f / velocityMmPerHr.pow(1.25f))
                AlertLevel.CRITICAL
            }
            fs < 1.35f -> {
                velocityMmPerHr = 0.08f * (1.5f / fs)
                ttfHours = null
                AlertLevel.WARNING
            }
            else -> {
                velocityMmPerHr = 0.002f
                ttfHours = null
                AlertLevel.STABLE
            }
        }

        return TelemetryRecord(
            timestampMs = timestampMs,
            rawForce = rawForce,
            rawIR = rawIR,
            rawSoil = rawSoil,
            accX = rawAccX,
            accY = rawAccY,
            accZ = rawAccZ,
            forceN = forceN,
            pressureKPa = pressureKPa,
            momentNm = momentNm,
            distCm = distCm,
            dispMm = dispMm,
            soilMoisturePct = soilMoisturePct,
            tiltDeg = tiltDeg,
            tiltX = tiltX,
            tiltY = tiltY,
            pgaMg = pgaMg,
            factorOfSafety = fs,
            shearResistanceKPa = shearResistance,
            mobilizedShearKPa = mobilizedShear,
            velocityMmPerHr = velocityMmPerHr,
            ttfHours = ttfHours,
            alertLevel = alertLevel
        )
    }
}
