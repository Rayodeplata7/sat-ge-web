package com.satgeo.telemetry.engine

import kotlin.math.*

data class TelemetryRecord(
    val timestampMs: Long,
    val rawForce: Int,
    val rawIR: Int,
    val rawSoil: Int,
    val accX: Int,
    val accY: Int,
    val accZ: Int,
    val forceN: Float,
    val pressureKPa: Float,
    val momentNm: Float,
    val distCm: Float,
    val dispMm: Float,
    val soilMoisturePct: Float,
    val tiltDeg: Float,
    val tiltX: Float,
    val tiltY: Float,
    val pgaMg: Float,
    val factorOfSafety: Float,
    val shearResistanceKPa: Float,
    val mobilizedShearKPa: Float,
    val velocityMmPerHr: Float,
    val ttfHours: Float?,
    val alertLevel: AlertLevel,
    val sensorWarnings: List<String> = emptyList()
)

enum class AlertLevel {
    STABLE,
    WARNING,
    CRITICAL
}

class GeomechanicalEngine {
    private val cohesionKPa = 24.0f
    private val frictionAngleDeg = 32.0f
    private val soilUnitWeightKNm3 = 18.5f
    private val slopeHeightM = 3.2f
    private val slopeAngleDeg = 40.0f

    private var lastStableState = AlertLevel.STABLE
    private var pendingState = AlertLevel.STABLE
    private var consecutiveCount = 0
    private var zeroDispMm = 0f
    private var zeroTiltDeg = 0f
    private var lastRawDispMm = 0f
    private var lastRawTiltDeg = 0f

    fun calibrateZero() {
        zeroDispMm = lastRawDispMm
        zeroTiltDeg = lastRawTiltDeg
    }

    fun resetZero() {
        zeroDispMm = 0f
        zeroTiltDeg = 0f
    }

    fun processSample(
        timestampMs: Long,
        rawForce: Int,
        rawIR: Int,
        rawSoil: Int = 3250,
        accX: Int = 1,
        accY: Int = 0,
        accZ: Int = 256
    ): TelemetryRecord {
        val forceN = if (rawForce > 65) min(4.4f, (rawForce - 65) * 0.01467f) else 0f
        val pressureKPa = forceN * 2.5f
        val momentNm = forceN * 0.88f

        val distCm = max(0.2f, 5.0f - (rawIR / 4095f) * 4.6f)
        val rawDispMm = max(0f, (5.0f - distCm) * 10.0f)
        val soilMoisturePct = max(5.0f, min(100.0f, ((3800f - rawSoil) / 2600f) * 100f))

        val azSafe = max(1f, abs(accZ.toFloat()))
        val tiltX = atan2(accX.toFloat(), azSafe) * (180f / PI.toFloat())
        val tiltY = atan2(accY.toFloat(), azSafe) * (180f / PI.toFloat())
        val rawTiltDeg = atan2(hypot(accX.toFloat(), accY.toFloat()), azSafe) * (180f / PI.toFloat())
        lastRawDispMm = rawDispMm
        lastRawTiltDeg = rawTiltDeg
        val dispMm = abs(rawDispMm - zeroDispMm)
        val tiltDeg = abs(rawTiltDeg - zeroTiltDeg)
        val mag = sqrt((accX * accX + accY * accY + accZ * accZ).toFloat())
        val vibG = abs((mag / 256f) - 1.0f)
        val pgaMg = vibG * 1000f

        val satFactor = max(0f, (soilMoisturePct - 15f) / 85f)
        val porePressureKPa = satFactor * 16.5f
        val beta = slopeAngleDeg * (PI.toFloat() / 180f)
        val phi = frictionAngleDeg * (PI.toFloat() / 180f)

        val sigmaN = soilUnitWeightKNm3 * slopeHeightM * cos(beta) * cos(beta)
        val sigmaEff = max(2f, sigmaN - porePressureKPa)
        val shearRes = cohesionKPa + sigmaEff * tan(phi)

        val drivingBase = soilUnitWeightKNm3 * slopeHeightM * sin(beta) * cos(beta)
        val extForce = forceN * 1.45f + dispMm * 0.18f + tiltDeg * 0.25f + vibG * 14f
        val mobilized = max(1f, drivingBase + extForce)
        val fs = (shearRes / mobilized).coerceIn(0.45f, 2.60f)

        val rawLevel = when {
            fs < 1.0f -> AlertLevel.CRITICAL
            fs < 1.35f -> AlertLevel.WARNING
            else -> AlertLevel.STABLE
        }

        // Hysteresis/debounce to avoid flickering at boundary
        if (rawLevel == pendingState) {
            consecutiveCount++
            if (consecutiveCount >= 3) lastStableState = rawLevel
        } else {
            pendingState = rawLevel
            consecutiveCount = 1
        }

        val ttf = when (lastStableState) {
            AlertLevel.CRITICAL -> 0.4f
            AlertLevel.WARNING -> 4.2f
            AlertLevel.STABLE -> null
        }

        val warnings = ArrayList<String>()
        if (accX == 0 && accY == 0 && abs(accZ) < 20) {
            warnings.add("ADXL345 sin respuesta I2C (revisar GPIO21/22)")
        }
        if (rawSoil <= 15) {
            warnings.add("Sonda Humedad en corto a GND (ADC=$rawSoil)")
        }
        if (rawForce >= 4090) {
            warnings.add("Sensor FSR saturado o en corto (ADC=$rawForce)")
        }
        if (rawIR >= 4090) {
            warnings.add("Sensor IR fuera de rango (ADC=$rawIR)")
        }

        return TelemetryRecord(
            timestampMs, rawForce, rawIR, rawSoil, accX, accY, accZ,
            forceN, pressureKPa, momentNm, distCm, dispMm,
            soilMoisturePct, tiltDeg, tiltX, tiltY, pgaMg,
            fs, shearRes, mobilized, 0f, ttf, lastStableState, warnings
        )
    }
}
