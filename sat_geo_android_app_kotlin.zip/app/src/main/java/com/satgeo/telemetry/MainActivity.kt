package com.satgeo.telemetry

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.satgeo.telemetry.engine.AlertLevel
import com.satgeo.telemetry.ui.view.SlopeTwin3DView
import com.satgeo.telemetry.ui.view.SparklineView
import com.satgeo.telemetry.ui.view.StabilityGaugeView
import com.satgeo.telemetry.ui.view.TelemetrySurfaceView
import com.satgeo.telemetry.ui.viewmodel.TelemetryViewModel
import com.satgeo.telemetry.usb.UsbSerialService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val viewModel: TelemetryViewModel by viewModels()
    private lateinit var usbSerialService: UsbSerialService

    private var toneGenerator: ToneGenerator? = null
    private var vibrator: Vibrator? = null
    private var lastAlarmTime = 0L
    private var lastUiUpdateTime = 0L
    private var lastNotifiedLevel: AlertLevel = AlertLevel.STABLE
    private var lastLoggedLevel: AlertLevel? = null
    private var isAlarmMuted = false

    private val eventLines = ArrayList<String>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    // Views
    private lateinit var tvStatusConnection: TextView
    private lateinit var btnQuickMute: Button
    private lateinit var tabLive: LinearLayout
    private lateinit var tabAlerts: LinearLayout
    private lateinit var tabConnect: LinearLayout
    private lateinit var navLive: Button
    private lateinit var navAlerts: Button
    private lateinit var navConnect: Button

    private lateinit var stabilityGauge: StabilityGaugeView
    private lateinit var slopeTwin3D: SlopeTwin3DView
    private lateinit var tvAlarmLevel: TextView
    private lateinit var tvActionAdvice: TextView
    private lateinit var tvSensorDiagnostics: TextView
    private lateinit var tvMoisturePct: TextView
    private lateinit var tvTiltDeg: TextView
    private lateinit var tvDispMm: TextView
    private lateinit var tvForceN: TextView
    private lateinit var sparkHum: SparklineView
    private lateinit var sparkTilt: SparklineView
    private lateinit var sparkDisp: SparklineView
    private lateinit var sparkForce: SparklineView

    private lateinit var seekRain: SeekBar
    private lateinit var tvRainIntensity: TextView
    private lateinit var oscilloscopeView: TelemetrySurfaceView
    private lateinit var tvEventLog: TextView
    private lateinit var btnConnectUsb: Button
    private lateinit var btnConnectWifi: Button
    private lateinit var etServerIp: EditText

    private val notificationPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(this, "Activa notificaciones para recibir alertas del talud", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createAlertNotificationChannel()
        requestNotificationPermissionIfNeeded()
        initHardwarePeripherals()
        initViews()
        initUsbService()
        observeViewModel()
    }

    private fun createAlertNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Alertas Críticas SAT-GEO",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notificaciones de riesgo de deslizamiento en tiempo real"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 150, 300)
                setSound(soundUri, null)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun initHardwarePeripherals() {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 85)
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (_: Exception) {}
    }

    private fun initViews() {
        tvStatusConnection = findViewById(R.id.tvStatusConnection)
        btnQuickMute = findViewById(R.id.btnQuickMute)
        tabLive = findViewById(R.id.tabLive)
        tabAlerts = findViewById(R.id.tabAlerts)
        tabConnect = findViewById(R.id.tabConnect)
        navLive = findViewById(R.id.navLive)
        navAlerts = findViewById(R.id.navAlerts)
        navConnect = findViewById(R.id.navConnect)

        stabilityGauge = findViewById(R.id.stabilityGauge)
        slopeTwin3D = findViewById(R.id.slopeTwin3D)
        tvAlarmLevel = findViewById(R.id.tvAlarmLevel)
        tvActionAdvice = findViewById(R.id.tvActionAdvice)
        tvSensorDiagnostics = findViewById(R.id.tvSensorDiagnostics)
        tvMoisturePct = findViewById(R.id.tvMoisturePct)
        tvTiltDeg = findViewById(R.id.tvTiltDeg)
        tvDispMm = findViewById(R.id.tvDispMm)
        tvForceN = findViewById(R.id.tvForceN)

        sparkHum = findViewById<SparklineView>(R.id.sparkHum).apply { configure("#38BDF8", 100f) }
        sparkTilt = findViewById<SparklineView>(R.id.sparkTilt).apply { configure("#F59E0B", 15f) }
        sparkDisp = findViewById<SparklineView>(R.id.sparkDisp).apply { configure("#94A3B8", 40f) }
        sparkForce = findViewById<SparklineView>(R.id.sparkForce).apply { configure("#10B981", 4.5f) }

        seekRain = findViewById(R.id.seekRain)
        tvRainIntensity = findViewById(R.id.tvRainIntensity)
        oscilloscopeView = findViewById(R.id.oscilloscopeView)
        tvEventLog = findViewById(R.id.tvEventLog)
        btnConnectUsb = findViewById(R.id.btnConnectUsb)
        btnConnectWifi = findViewById(R.id.btnConnectWifi)
        etServerIp = findViewById(R.id.etServerIp)

        navLive.setOnClickListener { switchTab(0) }
        navAlerts.setOnClickListener { switchTab(1) }
        navConnect.setOnClickListener { switchTab(2) }

        findViewById<Button>(R.id.btnZeroCal).setOnClickListener {
            viewModel.calibrateZero()
            Toast.makeText(this, "Sensores tarados a 0.0 mm / 0.00°", Toast.LENGTH_SHORT).show()
        }

        btnQuickMute.setOnClickListener {
            isAlarmMuted = !isAlarmMuted
            btnQuickMute.text = if (isAlarmMuted) "Silenciado" else "Silenciar"
        }

        seekRain.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvRainIntensity.text = "$progress% Lluvia"
                if (fromUser) viewModel.setRainLevel(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnSimNormal).setOnClickListener {
            seekRain.progress = 0
            tvRainIntensity.text = "0% Lluvia"
            viewModel.setSimulationScenario("normal")
        }
        findViewById<Button>(R.id.btnSimRain).setOnClickListener {
            seekRain.progress = 80
            tvRainIntensity.text = "80% Lluvia"
            viewModel.setSimulationScenario("rain")
        }
        findViewById<Button>(R.id.btnSimSeismic).setOnClickListener {
            seekRain.progress = 95
            tvRainIntensity.text = "Sismo + Lluvia"
            viewModel.setSimulationScenario("seismic")
        }

        findViewById<Button>(R.id.btnTestNotification).setOnClickListener {
            sendSystemNotification(
                "Prueba de Alerta SAT-GEO",
                "Las notificaciones de riesgo en tu teléfono están activas y funcionando.",
                AlertLevel.WARNING,
                force = true
            )
            triggerHazardAlarm(isCritical = false)
            Toast.makeText(this, "Notificación enviada al teléfono", Toast.LENGTH_SHORT).show()
        }

        btnConnectUsb.setOnClickListener {
            if (usbSerialService.isConnected()) {
                usbSerialService.disconnect()
            } else {
                val ok = usbSerialService.connect()
                if (!ok) Toast.makeText(this, "Conecta el ESP32 por cable USB OTG", Toast.LENGTH_SHORT).show()
            }
        }

        btnConnectWifi.setOnClickListener {
            if (viewModel.isHttpConnected.value) {
                viewModel.disconnectHttp()
            } else {
                if (usbSerialService.isConnected()) {
                    usbSerialService.disconnect()
                }
                val ip = etServerIp.text.toString().ifBlank { "192.168.4.1" }
                viewModel.connectHttpEndpoint(ip, ip)
            }
        }
    }

    private fun switchTab(idx: Int) {
        tabLive.visibility = if (idx == 0) View.VISIBLE else View.GONE
        tabAlerts.visibility = if (idx == 1) View.VISIBLE else View.GONE
        tabConnect.visibility = if (idx == 2) View.VISIBLE else View.GONE

        navLive.setTextColor(Color.parseColor(if (idx == 0) "#FFFFFF" else "#64748B"))
        navAlerts.setTextColor(Color.parseColor(if (idx == 1) "#FFFFFF" else "#64748B"))
        navConnect.setTextColor(Color.parseColor(if (idx == 2) "#FFFFFF" else "#64748B"))
    }

    private fun initUsbService() {
        usbSerialService = UsbSerialService(this)
        usbSerialService.setOnPacketReceivedListener { rawForce, rawIR, rawSoil, ax, ay, az ->
            viewModel.onHardwarePacket(rawForce, rawIR, rawSoil, ax, ay, az)
        }
        usbSerialService.setOnConnectionStateChangedListener { connected, status ->
            runOnUiThread {
                viewModel.setHardwareState(connected, status)
                btnConnectUsb.text = if (connected) "Desconectar USB" else "Conectar ESP32 por USB"
            }
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.connectionStatus.collectLatest { tvStatusConnection.text = it }
        }
        lifecycleScope.launch {
            viewModel.isHttpConnected.collectLatest { on ->
                btnConnectWifi.text = if (on) "Desconectar Wi-Fi / Servidor" else "Conectar por Wi-Fi"
            }
        }
        lifecycleScope.launch {
            viewModel.telemetryState.collectLatest { record ->
                record ?: return@collectLatest
                oscilloscopeView.pushSample(record.forceN, record.distCm)

                val now = System.currentTimeMillis()
                if (now - lastUiUpdateTime < 100 && record.alertLevel == lastNotifiedLevel) return@collectLatest
                lastUiUpdateTime = now

                stabilityGauge.setFactorOfSafety(record.factorOfSafety)
                slopeTwin3D.updateTelemetry(record.tiltDeg, record.dispMm, record.soilMoisturePct, record.alertLevel)

                tvMoisturePct.text = String.format("%.1f %%", record.soilMoisturePct)
                tvTiltDeg.text = String.format("%.2f °", record.tiltDeg)
                tvDispMm.text = String.format("%.1f mm", record.dispMm)
                tvForceN.text = String.format("%.2f N", record.forceN)

                sparkHum.push(record.soilMoisturePct)
                sparkTilt.push(record.tiltDeg)
                sparkDisp.push(record.dispMm)
                sparkForce.push(record.forceN)

                if (record.sensorWarnings.isNotEmpty() &&
                    (viewModel.isHardwareConnected.value || viewModel.isHttpConnected.value)
                ) {
                    tvSensorDiagnostics.visibility = View.VISIBLE
                    tvSensorDiagnostics.text = "⚠ " + record.sensorWarnings.joinToString(" · ")
                } else {
                    tvSensorDiagnostics.visibility = View.GONE
                }

                when (record.alertLevel) {
                    AlertLevel.CRITICAL -> {
                        tvAlarmLevel.text = "ALERTA CRÍTICA · EVACUAR"
                        tvAlarmLevel.setTextColor(Color.parseColor("#EF4444"))
                        tvActionAdvice.text = "Riesgo alto de deslizamiento (FS ${String.format("%.2f", record.factorOfSafety)}). Evacuar el sector."
                        triggerHazardAlarm(isCritical = true)
                        sendSystemNotification(
                            "ALERTA CRÍTICA DE TALUD (FS ${String.format("%.2f", record.factorOfSafety)})",
                            "Riesgo alto de deslizamiento. Humedad ${record.soilMoisturePct.toInt()}%, grieta ${String.format("%.1f", record.dispMm)} mm.",
                            AlertLevel.CRITICAL
                        )
                    }
                    AlertLevel.WARNING -> {
                        tvAlarmLevel.text = "PRECAUCIÓN · SATURACIÓN"
                        tvAlarmLevel.setTextColor(Color.parseColor("#F59E0B"))
                        tvActionAdvice.text = "Suelo saturado o empuje elevado (FS ${String.format("%.2f", record.factorOfSafety)}). Vigilar drenajes."
                        triggerHazardAlarm(isCritical = false)
                        sendSystemNotification(
                            "PRECAUCIÓN EN TALUD (FS ${String.format("%.2f", record.factorOfSafety)})",
                            "Incremento de humedad (${record.soilMoisturePct.toInt()}%) o movimiento detectado.",
                            AlertLevel.WARNING
                        )
                    }
                    AlertLevel.STABLE -> {
                        tvAlarmLevel.text = "TERRENO SEGURO"
                        tvAlarmLevel.setTextColor(Color.parseColor("#10B981"))
                        tvActionAdvice.text = "Estabilidad óptima. Sin saturación ni movimiento crítico."
                        lastNotifiedLevel = AlertLevel.STABLE
                    }
                }

                if (lastLoggedLevel != record.alertLevel) {
                    lastLoggedLevel = record.alertLevel
                    val stamp = timeFmt.format(Date())
                    val label = when (record.alertLevel) {
                        AlertLevel.CRITICAL -> "CRÍTICO"
                        AlertLevel.WARNING -> "PRECAUCIÓN"
                        AlertLevel.STABLE -> "ESTABLE"
                    }
                    eventLines.add(0, "[$stamp] $label — FS ${String.format("%.2f", record.factorOfSafety)} · Hum ${record.soilMoisturePct.toInt()}% · Grieta ${String.format("%.1f", record.dispMm)} mm")
                    if (eventLines.size > 15) eventLines.removeAt(eventLines.lastIndex)
                    tvEventLog.text = eventLines.joinToString("\n")
                }
            }
        }
    }

    private fun triggerHazardAlarm(isCritical: Boolean) {
        if (isAlarmMuted) return
        val now = System.currentTimeMillis()
        if (now - lastAlarmTime < (if (isCritical) 1400L else 4000L)) return
        lastAlarmTime = now

        val tone = if (isCritical) ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK else ToneGenerator.TONE_PROP_BEEP
        try {
            toneGenerator?.startTone(tone, if (isCritical) 220 else 100)
        } catch (_: Exception) {}

        val pattern = if (isCritical) longArrayOf(0, 220, 100, 220) else longArrayOf(0, 120)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(if (isCritical) 260L else 120L)
        }
    }

    private fun sendSystemNotification(title: String, body: String, level: AlertLevel, force: Boolean = false) {
        if (!force && lastNotifiedLevel == level) return
        if (!force) lastNotifiedLevel = level

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE)

        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(if (force) 1002 else 1001, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        usbSerialService.disconnect()
        viewModel.disconnectHttp()
        toneGenerator?.release()
    }

    companion object {
        private const val CHANNEL_ID = "satgeo_alerts_v2"
    }
}
