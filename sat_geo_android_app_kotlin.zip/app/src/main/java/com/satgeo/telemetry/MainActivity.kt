package com.satgeo.telemetry

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.satgeo.telemetry.engine.AlertLevel
import com.satgeo.telemetry.ui.viewmodel.TelemetryViewModel
import com.satgeo.telemetry.usb.UsbSerialService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val viewModel: TelemetryViewModel by viewModels()
    private lateinit var usbSerialService: UsbSerialService

    private var toneGenerator: ToneGenerator? = null
    private var vibrator: Vibrator? = null
    private var lastAlarmTime = 0L
    private var lastUiUpdateTime = 0L
    private var lastNotifiedLevel: AlertLevel = AlertLevel.STABLE
    private var isAlarmMuted = false

    private lateinit var tvStatusConnection: TextView
    private lateinit var btnConnectUsb: Button
    private lateinit var btnConnectWifi: Button
    private lateinit var btnMuteAlarm: Button
    private lateinit var cardFSSafety: LinearLayout
    private lateinit var tvFSValue: TextView
    private lateinit var tvAlarmLevel: TextView
    private lateinit var tvActionAdvice: TextView
    private lateinit var pbFSProgress: ProgressBar
    private lateinit var tvMoisturePct: TextView
    private lateinit var tvTiltDeg: TextView
    private lateinit var tvDispMm: TextView
    private lateinit var tvForceN: TextView

    private val notificationPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Permission handled gracefully */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createAlertNotificationChannel()
        requestNotificationPermissionIfNeeded()
        initHardwarePeripherals()
        initViews()
        initUsbService()
        observeViewModel()
    }

    private fun createAlertNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Alertas Geotécnicas SAT-GEO",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notificaciones de precaución y evacuación del talud"
                enableVibration(true)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun initHardwarePeripherals() {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 80)
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (_: Exception) {
        }
    }

    private fun initViews() {
        tvStatusConnection = findViewById(R.id.tvStatusConnection)
        btnConnectUsb = findViewById(R.id.btnConnectUsb)
        btnConnectWifi = findViewById(R.id.btnConnectWifi)
        btnMuteAlarm = findViewById(R.id.btnMuteAlarm)
        cardFSSafety = findViewById(R.id.cardFSSafety)
        tvFSValue = findViewById(R.id.tvFSValue)
        tvAlarmLevel = findViewById(R.id.tvAlarmLevel)
        tvActionAdvice = findViewById(R.id.tvActionAdvice)
        pbFSProgress = findViewById(R.id.pbFSProgress)
        tvMoisturePct = findViewById(R.id.tvMoisturePct)
        tvTiltDeg = findViewById(R.id.tvTiltDeg)
        tvDispMm = findViewById(R.id.tvDispMm)
        tvForceN = findViewById(R.id.tvForceN)

        btnConnectUsb.setOnClickListener {
            if (usbSerialService.isConnected()) {
                usbSerialService.disconnect()
            } else {
                val ok = usbSerialService.connect()
                if (!ok) {
                    Toast.makeText(this, "Conecta el cable USB OTG al ESP32", Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnConnectWifi.setOnClickListener {
            viewModel.toggleWifi("192.168.4.1")
        }

        btnMuteAlarm.setOnClickListener {
            isAlarmMuted = !isAlarmMuted
            btnMuteAlarm.text = if (isAlarmMuted) "Alarma Silenciada (Tocar para activar)" else "Silenciar Alerta"
        }

        findViewById<Button>(R.id.btnSimRain).setOnClickListener {
            viewModel.setSimulationScenario("rain")
        }

        findViewById<Button>(R.id.btnSimReset).setOnClickListener {
            viewModel.setSimulationScenario("normal")
        }
    }

    private fun initUsbService() {
        usbSerialService = UsbSerialService(this)

        usbSerialService.setOnPacketReceivedListener { rawForce, rawIR, rawSoil, ax, ay, az ->
            viewModel.onHardwarePacket(rawForce, rawIR, rawSoil, ax, ay, az)
        }

        usbSerialService.setOnConnectionStateChangedListener { connected, status ->
            runOnUiThread {
                viewModel.setHardwareState(connected, status)
                btnConnectUsb.text = if (connected) "Salir USB" else "USB"
            }
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.connectionStatus.collectLatest { status ->
                tvStatusConnection.text = status
            }
        }

        lifecycleScope.launch {
            viewModel.isWifiConnected.collectLatest { wifiOn ->
                btnConnectWifi.text = if (wifiOn) "Salir Wi-Fi" else "Wi-Fi"
            }
        }

        lifecycleScope.launch {
            viewModel.telemetryState.collectLatest { record ->
                record ?: return@collectLatest
                val now = System.currentTimeMillis()
                if (now - lastUiUpdateTime < 100 && record.alertLevel == lastNotifiedLevel) {
                    return@collectLatest
                }
                lastUiUpdateTime = now

                tvMoisturePct.text = String.format("%.1f %%", record.soilMoisturePct)
                tvTiltDeg.text = String.format("%.2f °", record.tiltDeg)
                tvDispMm.text = String.format("%.1f mm", record.dispMm)
                tvForceN.text = String.format("%.2f N", record.forceN)
                tvFSValue.text = String.format("%.2f", record.factorOfSafety)
                pbFSProgress.progress = (record.factorOfSafety * 100).toInt().coerceIn(0, 250)

                when (record.alertLevel) {
                    AlertLevel.CRITICAL -> {
                        val critColor = Color.parseColor("#EF4444")
                        tvAlarmLevel.text = "ALERTA CRÍTICA · EVACUAR"
                        tvAlarmLevel.setTextColor(critColor)
                        tvActionAdvice.text = "Riesgo alto de deslizamiento. Evacuar el sector inmediatamente."
                        cardFSSafety.setBackgroundResource(R.drawable.bg_hud_danger)
                        pbFSProgress.progressTintList = ColorStateList.valueOf(critColor)
                        triggerHazardAlarm(isCritical = true)
                        sendSystemNotification(
                            "ALERTA CRÍTICA DE TALUD (FS ${String.format("%.2f", record.factorOfSafety)})",
                            "Riesgo alto de deslizamiento. Evacuar el sector inmediatamente.",
                            record.alertLevel
                        )
                    }
                    AlertLevel.WARNING -> {
                        val warnColor = Color.parseColor("#F59E0B")
                        tvAlarmLevel.text = "PRECAUCIÓN"
                        tvAlarmLevel.setTextColor(warnColor)
                        tvActionAdvice.text = "Suelo saturado o empuje elevado. Monitoreo preventivo activo."
                        cardFSSafety.setBackgroundResource(R.drawable.bg_hud_card)
                        pbFSProgress.progressTintList = ColorStateList.valueOf(warnColor)
                        triggerHazardAlarm(isCritical = false)
                        sendSystemNotification(
                            "PRECAUCIÓN EN TALUD (FS ${String.format("%.2f", record.factorOfSafety)})",
                            "Incremento de humedad o movimiento detectado.",
                            record.alertLevel
                        )
                    }
                    AlertLevel.STABLE -> {
                        val okColor = Color.parseColor("#10B981")
                        tvAlarmLevel.text = "TERRENO ESTABLE"
                        tvAlarmLevel.setTextColor(okColor)
                        tvActionAdvice.text = "Condición segura. No se detecta movimiento ni saturación crítica."
                        cardFSSafety.setBackgroundResource(R.drawable.bg_hud_card)
                        pbFSProgress.progressTintList = ColorStateList.valueOf(okColor)
                        lastNotifiedLevel = AlertLevel.STABLE
                    }
                }
            }
        }
    }

    private fun triggerHazardAlarm(isCritical: Boolean) {
        if (isAlarmMuted) return
        val now = System.currentTimeMillis()
        val cooldown = if (isCritical) 1400L else 4000L
        if (now - lastAlarmTime < cooldown) return
        lastAlarmTime = now

        val tone = if (isCritical) ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK else ToneGenerator.TONE_PROP_BEEP
        toneGenerator?.startTone(tone, if (isCritical) 220 else 100)

        val duration = if (isCritical) 280L else 120L
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(duration)
        }
    }

    private fun sendSystemNotification(title: String, body: String, level: AlertLevel) {
        if (lastNotifiedLevel == level) return
        lastNotifiedLevel = level

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1001, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        usbSerialService.disconnect()
        viewModel.disconnectWifi()
        toneGenerator?.release()
    }

    companion object {
        private const val CHANNEL_ID = "satgeo_alerts"
    }
}
