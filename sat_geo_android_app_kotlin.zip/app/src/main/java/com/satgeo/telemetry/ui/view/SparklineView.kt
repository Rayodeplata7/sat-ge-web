package com.satgeo.telemetry.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

class SparklineView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val values = ArrayList<Float>(32)
    private var maxVal = 100f

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.parseColor("#10B981")
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#2210B981")
    }

    private val path = Path()
    private val fillPath = Path()

    fun configure(colorHex: String, maxValue: Float) {
        val c = Color.parseColor(colorHex)
        linePaint.color = c
        fillPaint.color = Color.argb(38, Color.red(c), Color.green(c), Color.blue(c))
        maxVal = maxValue
    }

    fun push(v: Float) {
        if (values.size >= 30) values.removeAt(0)
        values.add(v)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (values.size < 2 || width <= 0 || height <= 0) return

        path.reset()
        fillPath.reset()
        val w = width.toFloat()
        val h = height.toFloat()

        for (i in values.indices) {
            val x = (i / 29f) * w
            val norm = (values[i] / maxVal).coerceIn(0f, 1f)
            val y = h - 4f - norm * (h - 8f)
            if (i == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, h)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        val lastX = ((values.size - 1) / 29f) * w
        fillPath.lineTo(lastX, h)
        fillPath.close()

        canvas.drawPath(fillPath, fillPaint)
        canvas.drawPath(path, linePaint)
    }
}
