package com.satgeo.telemetry.engine

import kotlin.math.*

data class TelemetryRecord(
    val timestampMs: Long,
    val rawForce: Int,
    val rawIR: Int,
    val rawSoil: Int,
    val accX: Int,
    val accY: Int,
    val accZ: Int,
    val forceN: Float,
    val pressureKPa: Float,
    val momentNm: Float,
    val distCm: Float,
    val dispMm: Float,
    val soilMoisturePct: Float,
    val tiltDeg: Float,
    val tiltX: Float,
    val tiltY: Float,
    val pgaMg: Float,
    val factorOfSafety: Float,
    val shearResistanceKPa: Float,
    val mobilizedShearKPa: Float,
    val velocityMmPerHr: Float,
    val ttfHours: Float?,
    val alertLevel: AlertLevel,
    val sensorWarnings: List<String> = emptyList()
)

enum class AlertLevel {
    STABLE,
    WARNING,
    CRITICAL
}

class GeomechanicalEngine {
    private val cohesionKPa = 24.0f
    private val frictionAngleDeg = 32.0f
    private val soilUnitWeightKNm3 = 18.5f
    private val slopeHeightM = 3.2f
    private val slopeAngleDeg = 40.0f

    private var lastStableState = AlertLevel.STABLE
    private var pendingState = AlertLevel.STABLE
    private var consecutiveCount = 0

    private var hasBaseline = false
    private var tareSamples = 0
    private var sumFsr = 0f
    private var sumIr = 0f
    private var sumSoil = 0f
    private var sumAx = 0f
    private var sumAy = 0f
    private var sumAz = 0f

    private var emaFsr: Float? = null
    private var emaIr: Float? = null
    private var emaSoil: Float? = null
    private var emaAx: Float? = null
    private var emaAy: Float? = null
    private var emaAz: Float? = null

    private var baseFsr = 65f
    private var baseIr = 4095f
    private var baseSoil = 4095f
    private var baseAx = 0f
    private var baseAy = 0f
    private var baseAz = 256f
    private var prevAx = 0
    private var prevAy = 0
    private var prevAz = 256
    private var vibPeak = 0f

    private var lastFsr = 65
    private var lastIr = 4095
    private var lastSoil = 4095
    private var lastAx = 0
    private var lastAy = 0
    private var lastAz = 256

    fun calibrateZero() {
        hasBaseline = true
        tareSamples = 6
        baseFsr = emaFsr ?: lastFsr.toFloat()
        baseIr = emaIr ?: lastIr.toFloat()
        baseSoil = emaSoil ?: lastSoil.toFloat()
        baseAx = emaAx ?: lastAx.toFloat()
        baseAy = emaAy ?: lastAy.toFloat()
        baseAz = emaAz ?: lastAz.toFloat()
        vibPeak = 0f
    }

    fun resetZero() {
        hasBaseline = false
        tareSamples = 0
        sumFsr = 0f; sumIr = 0f; sumSoil = 0f
        sumAx = 0f; sumAy = 0f; sumAz = 0f
        emaFsr = null; emaIr = null; emaSoil = null
        emaAx = null; emaAy = null; emaAz = null
        vibPeak = 0f
    }

    fun processSample(
        timestampMs: Long,
        rawForce: Int,
        rawIR: Int,
        rawSoil: Int = 4095,
        accX: Int = 0,
        accY: Int = 0,
        accZ: Int = 256
    ): TelemetryRecord {
        lastFsr = rawForce
        lastIr = rawIR
        lastSoil = rawSoil
        lastAx = accX
        lastAy = accY
        lastAz = accZ

        // Fast low-latency EMA filters for razor-sharp response without resting jitter
        val fFsr = emaFsr?.let { it * 0.65f + rawForce * 0.35f } ?: rawForce.toFloat()
        val fIr = emaIr?.let { it * 0.50f + rawIR * 0.50f } ?: rawIR.toFloat()
        val fSoil = emaSoil?.let { it * 0.50f + rawSoil * 0.50f } ?: rawSoil.toFloat()
        val fAx = emaAx?.let { it * 0.50f + accX * 0.50f } ?: accX.toFloat()
        val fAy = emaAy?.let { it * 0.50f + accY * 0.50f } ?: accY.toFloat()
        val fAz = emaAz?.let { it * 0.50f + accZ * 0.50f } ?: accZ.toFloat()
        emaFsr = fFsr; emaIr = fIr; emaSoil = fSoil
        emaAx = fAx; emaAy = fAy; emaAz = fAz

        if (!hasBaseline) {
            sumFsr += fFsr
            sumIr += fIr
            sumSoil += fSoil
            sumAx += fAx
            sumAy += fAy
            sumAz += fAz
            tareSamples++
            baseFsr = sumFsr / tareSamples
            baseIr = sumIr / tareSamples
            baseSoil = sumSoil / tareSamples
            baseAx = sumAx / tareSamples
            baseAy = sumAy / tareSamples
            baseAz = sumAz / tareSamples
            prevAx = accX; prevAy = accY; prevAz = accZ
            if (tareSamples >= 6) hasBaseline = true
        }

        // 1) FSR-406: ultra-sensitive (deadband 14 ADC just above resting noise)
        val deltaFsr = max(0f, abs(fFsr - baseFsr) - 14f)
        val forceN = min(5.0f, deltaFsr * 0.032f)
        val pressureKPa = forceN * 2.5f
        val momentNm = forceN * 0.88f

        // 2) IR P/N 1102: ultra-sensitive (resting noise = 0, deadband 4 ADC)
        val deltaIr = max(0f, abs(fIr - baseIr) - 4f)
        val dispMm = min(50.0f, deltaIr * 0.065f)
        val distCm = max(0.2f, 5.0f - (dispMm / 10.0f))

        // 3) Soil Moisture Fork: ultra-sensitive to even a single water drop or moist touch
        val absHum = 8.0f + ((4092f - fSoil) / 1500f) * 92f
        val relHum = 8.0f + ((baseSoil - fSoil) / 1100f) * 92f
        val soilMoisturePct = max(absHum, relHum).coerceIn(8.0f, 100.0f)

        // 4) ADXL345: 3D relative tilt angle (0.22 deg deadband, 2.4x gain) + micro-vibration (0.014g deadband)
        val azSafe = max(1f, abs(fAz))
        val tiltX = atan2(fAx, azSafe) * (180f / PI.toFloat())
        val tiltY = atan2(fAy, azSafe) * (180f / PI.toFloat())

        val magNow = sqrt(fAx * fAx + fAy * fAy + fAz * fAz)
        val magBase = sqrt(baseAx * baseAx + baseAy * baseAy + baseAz * baseAz)
        var rawAngle = 0f
        if (magNow > 10f && magBase > 10f) {
            val dot = fAx * baseAx + fAy * baseAy + fAz * baseAz
            val cosT = (dot / (magNow * magBase)).coerceIn(-1f, 1f)
            rawAngle = acos(cosT) * (180f / PI.toFloat())
        }
        val tiltDeg = if (rawAngle > 0.22f) ((rawAngle - 0.22f) * 2.4f).coerceIn(0f, 45f) else 0f

        val stepG = sqrt(
            ((accX - prevAx) * (accX - prevAx) +
             (accY - prevAy) * (accY - prevAy) +
             (accZ - prevAz) * (accZ - prevAz)).toFloat()
        ) / 256f
        prevAx = accX; prevAy = accY; prevAz = accZ
        vibPeak = max(stepG, vibPeak * 0.82f)
        val vibG = if (vibPeak > 0.014f) (vibPeak - 0.014f) * 4.0f else 0f
        val pgaMg = vibG * 1000f

        val satFactor = max(0f, (soilMoisturePct - 12f) / 88f)
        val porePressureKPa = satFactor * 20.0f
        val beta = slopeAngleDeg * (PI.toFloat() / 180f)
        val phi = frictionAngleDeg * (PI.toFloat() / 180f)

        val sigmaN = soilUnitWeightKNm3 * slopeHeightM * cos(beta) * cos(beta)
        val sigmaEff = max(2f, sigmaN - porePressureKPa)
        val shearRes = cohesionKPa + sigmaEff * tan(phi)

        val drivingBase = soilUnitWeightKNm3 * slopeHeightM * sin(beta) * cos(beta)
        val extForce = forceN * 2.1f + dispMm * 0.28f + tiltDeg * 0.40f + vibG * 18f
        val mobilized = max(1f, drivingBase + extForce)
        val fs = (shearRes / mobilized).coerceIn(0.45f, 2.60f)

        val rawLevel = when {
            fs < 1.0f -> AlertLevel.CRITICAL
            fs < 1.35f -> AlertLevel.WARNING
            else -> AlertLevel.STABLE
        }

        if (rawLevel == pendingState) {
            consecutiveCount++
            if (consecutiveCount >= 2) lastStableState = rawLevel
        } else {
            pendingState = rawLevel
            consecutiveCount = 1
        }

        val ttf = when (lastStableState) {
            AlertLevel.CRITICAL -> 0.4f
            AlertLevel.WARNING -> 4.2f
            AlertLevel.STABLE -> null
        }

        val warnings = ArrayList<String>()
        if (accX == 0 && accY == 0 && abs(accZ) < 20) {
            warnings.add("ADXL345 sin respuesta I2C (revisar GPIO21/22)")
        }
        if (rawSoil <= 15) {
            warnings.add("Sonda Humedad en corto a GND (ADC=$rawSoil)")
        }
        if (rawForce >= 4090) {
            warnings.add("Sensor FSR saturado o en corto (ADC=$rawForce)")
        }

        return TelemetryRecord(
            timestampMs, rawForce, rawIR, rawSoil, accX, accY, accZ,
            forceN, pressureKPa, momentNm, distCm, dispMm,
            soilMoisturePct, tiltDeg, tiltX, tiltY, pgaMg,
            fs, shearRes, mobilized, 0f, ttf, lastStableState, warnings
        )
    }
}
