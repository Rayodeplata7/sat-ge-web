package com.satgeo.telemetry.engine

import kotlin.math.*

data class TelemetryRecord(
    val timestampMs: Long,
    val rawForce: Int,
    val rawIR: Int,
    val rawSoil: Int,
    val accX: Int,
    val accY: Int,
    val accZ: Int,
    val forceN: Float,
    val pressureKPa: Float,
    val momentNm: Float,
    val distCm: Float,
    val dispMm: Float,
    val soilMoisturePct: Float,
    val tiltDeg: Float,
    val tiltX: Float,
    val tiltY: Float,
    val pgaMg: Float,
    val factorOfSafety: Float,
    val shearResistanceKPa: Float,
    val mobilizedShearKPa: Float,
    val velocityMmPerHr: Float,
    val ttfHours: Float?,
    val alertLevel: AlertLevel,
    val sensorWarnings: List<String> = emptyList()
)

enum class AlertLevel {
    STABLE,
    WARNING,
    CRITICAL
}

class GeomechanicalEngine {
    private val cohesionKPa = 24.0f
    private val frictionAngleDeg = 32.0f
    private val soilUnitWeightKNm3 = 18.5f
    private val slopeHeightM = 3.2f
    private val slopeAngleDeg = 40.0f

    private var lastStableState = AlertLevel.STABLE
    private var pendingState = AlertLevel.STABLE
    private var consecutiveCount = 0
    private var hasBaseline = false
    private var tareSamples = 0
    private var sumFsr = 0f
    private var sumIr = 0f
    private var sumAx = 0f
    private var sumAy = 0f
    private var sumAz = 0f
    private var emaFsr: Float? = null
    private var baseFsr = 65f
    private var baseIr = 4095f
    private var baseAx = 0f
    private var baseAy = 0f
    private var baseAz = 256f
    private var prevAx = 0
    private var prevAy = 0
    private var prevAz = 256
    private var vibPeak = 0f
    private var lastFsr = 65
    private var lastIr = 4095
    private var lastAx = 0
    private var lastAy = 0
    private var lastAz = 256

    fun calibrateZero() {
        hasBaseline = true
        tareSamples = 10
        baseFsr = emaFsr ?: lastFsr.toFloat()
        baseIr = lastIr.toFloat()
        baseAx = lastAx.toFloat()
        baseAy = lastAy.toFloat()
        baseAz = lastAz.toFloat()
        vibPeak = 0f
    }

    fun resetZero() {
        hasBaseline = false
        tareSamples = 0
        sumFsr = 0f; sumIr = 0f; sumAx = 0f; sumAy = 0f; sumAz = 0f
        emaFsr = null
        vibPeak = 0f
    }

    fun setSimBaseline() {
        hasBaseline = true
        tareSamples = 10
        emaFsr = 65f
        baseFsr = 65f
        baseIr = 4095f
        baseAx = 1f
        baseAy = 0f
        baseAz = 256f
        prevAx = 1
        prevAy = 0
        prevAz = 256
        vibPeak = 0f
    }

    fun processSample(
        timestampMs: Long,
        rawForce: Int,
        rawIR: Int,
        rawSoil: Int = 4095,
        accX: Int = 0,
        accY: Int = 0,
        accZ: Int = 256
    ): TelemetryRecord {
        lastFsr = rawForce
        lastIr = rawIR
        lastAx = accX
        lastAy = accY
        lastAz = accZ

        val filteredFsr = emaFsr?.let { it * 0.80f + rawForce * 0.20f } ?: rawForce.toFloat()
        emaFsr = filteredFsr

        if (!hasBaseline) {
            sumFsr += rawForce
            sumIr += rawIR
            sumAx += accX
            sumAy += accY
            sumAz += accZ
            tareSamples++
            baseFsr = sumFsr / tareSamples
            baseIr = sumIr / tareSamples
            baseAx = sumAx / tareSamples
            baseAy = sumAy / tareSamples
            baseAz = sumAz / tareSamples
            prevAx = accX
            prevAy = accY
            prevAz = accZ
            if (tareSamples >= 10) hasBaseline = true
        }

        val deltaFsr = max(0f, abs(filteredFsr - baseFsr) - 55f)
        val forceN = min(4.4f, deltaFsr * 0.022f)
        val pressureKPa = forceN * 2.5f
        val momentNm = forceN * 0.88f

        val deltaIr = max(0f, abs(rawIR - baseIr) - 25f)
        val dispMm = min(50.0f, deltaIr * 0.035f)
        val distCm = max(0.2f, 5.0f - (dispMm / 10.0f))
        val soilMoisturePct = max(8.0f, min(100.0f, 8.0f + ((4085f - rawSoil) / 2200f) * 92f))

        val azSafe = max(1f, abs(accZ.toFloat()))
        val tiltX = atan2(accX.toFloat(), azSafe) * (180f / PI.toFloat())
        val tiltY = atan2(accY.toFloat(), azSafe) * (180f / PI.toFloat())

        val magNow = sqrt((accX * accX + accY * accY + accZ * accZ).toFloat())
        val magBase = sqrt((baseAx * baseAx + baseAy * baseAy + baseAz * baseAz))
        var rawAngle = 0f
        if (magNow > 10f && magBase > 10f) {
            val dot = (accX * baseAx + accY * baseAy + accZ * baseAz)
            val cosT = (dot / (magNow * magBase)).coerceIn(-1f, 1f)
            rawAngle = acos(cosT) * (180f / PI.toFloat())
        }
        val tiltDeg = if (rawAngle > 0.35f) (rawAngle - 0.35f) * 1.8f else 0f

        val stepG = sqrt(((accX - prevAx) * (accX - prevAx) + (accY - prevAy) * (accY - prevAy) + (accZ - prevAz) * (accZ - prevAz)).toFloat()) / 256f
        prevAx = accX
        prevAy = accY
        prevAz = accZ
        vibPeak = max(stepG, vibPeak * 0.82f)
        val vibG = if (vibPeak > 0.025f) (vibPeak - 0.025f) * 2.5f else 0f
        val pgaMg = vibG * 1000f

        val satFactor = max(0f, (soilMoisturePct - 15f) / 85f)
        val porePressureKPa = satFactor * 16.5f
        val beta = slopeAngleDeg * (PI.toFloat() / 180f)
        val phi = frictionAngleDeg * (PI.toFloat() / 180f)

        val sigmaN = soilUnitWeightKNm3 * slopeHeightM * cos(beta) * cos(beta)
        val sigmaEff = max(2f, sigmaN - porePressureKPa)
        val shearRes = cohesionKPa + sigmaEff * tan(phi)

        val drivingBase = soilUnitWeightKNm3 * slopeHeightM * sin(beta) * cos(beta)
        val extForce = forceN * 1.45f + dispMm * 0.18f + tiltDeg * 0.25f + vibG * 14f
        val mobilized = max(1f, drivingBase + extForce)
        val fs = (shearRes / mobilized).coerceIn(0.45f, 2.60f)

        val rawLevel = when {
            fs < 1.0f -> AlertLevel.CRITICAL
            fs < 1.35f -> AlertLevel.WARNING
            else -> AlertLevel.STABLE
        }

        // Hysteresis/debounce to avoid flickering at boundary
        if (rawLevel == pendingState) {
            consecutiveCount++
            if (consecutiveCount >= 3) lastStableState = rawLevel
        } else {
            pendingState = rawLevel
            consecutiveCount = 1
        }

        val ttf = when (lastStableState) {
            AlertLevel.CRITICAL -> 0.4f
            AlertLevel.WARNING -> 4.2f
            AlertLevel.STABLE -> null
        }

        val warnings = ArrayList<String>()
        if (accX == 0 && accY == 0 && abs(accZ) < 20) {
            warnings.add("ADXL345 sin respuesta I2C (revisar GPIO21/22)")
        }
        if (rawSoil <= 15) {
            warnings.add("Sonda Humedad en corto a GND (ADC=$rawSoil)")
        }
        if (rawForce >= 4090) {
            warnings.add("Sensor FSR saturado o en corto (ADC=$rawForce)")
        }

        return TelemetryRecord(
            timestampMs, rawForce, rawIR, rawSoil, accX, accY, accZ,
            forceN, pressureKPa, momentNm, distCm, dispMm,
            soilMoisturePct, tiltDeg, tiltX, tiltY, pgaMg,
            fs, shearRes, mobilized, 0f, ttf, lastStableState, warnings
        )
    }
}
