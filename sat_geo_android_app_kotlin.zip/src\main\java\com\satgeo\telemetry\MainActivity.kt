package com.satgeo.telemetry

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.satgeo.telemetry.engine.AlertLevel
import com.satgeo.telemetry.engine.TelemetryRecord
import com.satgeo.telemetry.ui.view.SlopeTwin3DView
import com.satgeo.telemetry.ui.view.SparklineView
import com.satgeo.telemetry.ui.view.StabilityGaugeView
import com.satgeo.telemetry.ui.view.TelemetrySurfaceView
import com.satgeo.telemetry.ui.viewmodel.TelemetryViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val viewModel: TelemetryViewModel by viewModels()

    private var toneGenerator: ToneGenerator? = null
    private var vibrator: Vibrator? = null
    private var lastAlarmTime = 0L
    private var lastUiUpdateTime = 0L
    private var lastNotifiedLevel: AlertLevel = AlertLevel.STABLE
    private var lastLoggedLevel: AlertLevel? = null
    private var isAlarmMuted = false

    private val eventLines = ArrayList<String>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val isoFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    // Recolección de datos reales de los 4 sensores por momentos
    private val moments = listOf("M1_REPOSO", "M2_HUMEDAD", "M3_EMPUJE", "M4_INCLINACION", "M5_RECUPERACION")
    private var momentIdx = 0
    private var isRecordingData = true
    private var lastRecordedTime = 0L
    private var lastRecord: TelemetryRecord? = null
    private val csvRows = ArrayList<String>()

    // Views
    private lateinit var tvStatusConnection: TextView
    private lateinit var btnQuickMute: Button
    private lateinit var tvRecordedCount: TextView
    private lateinit var btnCycleMoment: Button
    private lateinit var btnToggleRecord: Button
    private lateinit var tabLive: LinearLayout
    private lateinit var tabAlerts: LinearLayout
    private lateinit var tabConnect: LinearLayout
    private lateinit var navLive: Button
    private lateinit var navAlerts: Button
    private lateinit var navConnect: Button

    private lateinit var stabilityGauge: StabilityGaugeView
    private lateinit var slopeTwin3D: SlopeTwin3DView
    private lateinit var tvAlarmLevel: TextView
    private lateinit var tvActionAdvice: TextView
    private lateinit var tvSensorDiagnostics: TextView
    private lateinit var tvMoisturePct: TextView
    private lateinit var tvTiltDeg: TextView
    private lateinit var tvDispMm: TextView
    private lateinit var tvForceN: TextView
    private lateinit var sparkHum: SparklineView
    private lateinit var sparkTilt: SparklineView
    private lateinit var sparkDisp: SparklineView
    private lateinit var sparkForce: SparklineView

    private lateinit var oscilloscopeView: TelemetrySurfaceView
    private lateinit var tvEventLog: TextView
    private lateinit var btnConnectWifi: Button
    private lateinit var etServerIp: EditText

    private val notificationPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(this, "Activa notificaciones para recibir alertas del talud", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createAlertNotificationChannel()
        requestNotificationPermissionIfNeeded()
        initHardwarePeripherals()
        initViews()
        observeViewModel()
    }

    private fun createAlertNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Alertas Críticas SAT-GEO",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notificaciones de riesgo de deslizamiento en tiempo real"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 150, 300)
                setSound(soundUri, null)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun initHardwarePeripherals() {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 85)
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (_: Exception) {}
    }

    private fun initViews() {
        tvStatusConnection = findViewById(R.id.tvStatusConnection)
        btnQuickMute = findViewById(R.id.btnQuickMute)
        tabLive = findViewById(R.id.tabLive)
        tabAlerts = findViewById(R.id.tabAlerts)
        tabConnect = findViewById(R.id.tabConnect)
        navLive = findViewById(R.id.navLive)
        navAlerts = findViewById(R.id.navAlerts)
        navConnect = findViewById(R.id.navConnect)

        stabilityGauge = findViewById(R.id.stabilityGauge)
        slopeTwin3D = findViewById(R.id.slopeTwin3D)
        tvAlarmLevel = findViewById(R.id.tvAlarmLevel)
        tvActionAdvice = findViewById(R.id.tvActionAdvice)
        tvSensorDiagnostics = findViewById(R.id.tvSensorDiagnostics)
        tvMoisturePct = findViewById(R.id.tvMoisturePct)
        tvTiltDeg = findViewById(R.id.tvTiltDeg)
        tvDispMm = findViewById(R.id.tvDispMm)
        tvForceN = findViewById(R.id.tvForceN)

        sparkHum = findViewById<SparklineView>(R.id.sparkHum).apply { configure("#38BDF8", 100f) }
        sparkTilt = findViewById<SparklineView>(R.id.sparkTilt).apply { configure("#F59E0B", 15f) }
        sparkDisp = findViewById<SparklineView>(R.id.sparkDisp).apply { configure("#00F0FF", 30f) }
        sparkForce = findViewById<SparklineView>(R.id.sparkForce).apply { configure("#10B981", 4.5f) }

        oscilloscopeView = findViewById(R.id.oscilloscopeView)
        tvEventLog = findViewById(R.id.tvEventLog)
        tvRecordedCount = findViewById(R.id.tvRecordedCount)
        btnCycleMoment = findViewById(R.id.btnCycleMoment)
        btnToggleRecord = findViewById(R.id.btnToggleRecord)
        btnConnectWifi = findViewById(R.id.btnConnectWifi)
        etServerIp = findViewById(R.id.etServerIp)

        btnCycleMoment.setOnClickListener {
            momentIdx = (momentIdx + 1) % moments.size
            val m = moments[momentIdx]
            btnCycleMoment.text = "Momento Activo: $m (Cambiar)"
            updateRecorderCounter()
        }
        btnToggleRecord.setOnClickListener {
            isRecordingData = !isRecordingData
            btnToggleRecord.text = if (isRecordingData) "Pausar" else "Grabar"
            updateRecorderCounter()
        }
        findViewById<Button>(R.id.btnSnapSample).setOnClickListener {
            val rec = lastRecord
            if (rec == null || !viewModel.isLiveReceiving.value) {
                Toast.makeText(this, "Conecta el ESP32 por Wi-Fi para capturar una muestra real", Toast.LENGTH_SHORT).show()
            } else {
                appendCsvRow(rec)
                Toast.makeText(this, "Muestra real guardada en ${moments[momentIdx]}", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btnClearData).setOnClickListener {
            csvRows.clear()
            updateRecorderCounter()
            Toast.makeText(this, "Ensayo reiniciado (0 muestras)", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnExportCsv).setOnClickListener {
            exportAndShareCsv()
        }

        navLive.setOnClickListener { switchTab(0) }
        navAlerts.setOnClickListener { switchTab(1) }
        navConnect.setOnClickListener { switchTab(2) }

        findViewById<Button>(R.id.btnZeroCal).setOnClickListener {
            viewModel.calibrateZero()
            Toast.makeText(this, "Sensores tarados a 0.0 mm / 0.00°", Toast.LENGTH_SHORT).show()
        }

        btnQuickMute.setOnClickListener {
            isAlarmMuted = !isAlarmMuted
            btnQuickMute.text = if (isAlarmMuted) "Silenciado" else "Silenciar"
        }

        findViewById<Button>(R.id.btnTestNotification).setOnClickListener {
            sendSystemNotification(
                "Prueba de Alerta SAT-GEO",
                "Las notificaciones de riesgo en tu teléfono están activas y funcionando.",
                AlertLevel.WARNING,
                force = true
            )
            triggerHazardAlarm(isCritical = false)
            Toast.makeText(this, "Notificación enviada al teléfono", Toast.LENGTH_SHORT).show()
        }

        btnConnectWifi.setOnClickListener {
            if (viewModel.isHttpConnected.value) {
                viewModel.disconnectHttp()
            } else {
                val ip = etServerIp.text.toString().ifBlank { "192.168.4.1" }
                viewModel.connectHttpEndpoint(ip, ip)
            }
        }
    }

    private fun switchTab(idx: Int) {
        tabLive.visibility = if (idx == 0) View.VISIBLE else View.GONE
        tabAlerts.visibility = if (idx == 1) View.VISIBLE else View.GONE
        tabConnect.visibility = if (idx == 2) View.VISIBLE else View.GONE

        navLive.setTextColor(Color.parseColor(if (idx == 0) "#FFFFFF" else "#64748B"))
        navAlerts.setTextColor(Color.parseColor(if (idx == 1) "#FFFFFF" else "#64748B"))
        navConnect.setTextColor(Color.parseColor(if (idx == 2) "#FFFFFF" else "#64748B"))
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.connectionStatus.collectLatest { tvStatusConnection.text = it }
        }
        lifecycleScope.launch {
            viewModel.isHttpConnected.collectLatest { on ->
                btnConnectWifi.text = if (on) "Desconectar Wi-Fi" else "Conectar por Wi-Fi"
            }
        }
        lifecycleScope.launch {
            viewModel.telemetryState.collectLatest { record ->
                record ?: return@collectLatest
                lastRecord = record
                oscilloscopeView.pushSample(
                    record.forceN,
                    record.dispMm,
                    record.soilMoisturePct,
                    record.tiltDeg,
                    record.pgaMg
                )

                val now = System.currentTimeMillis()
                // Grabar automáticamente 1 muestra real cada 1000 ms solo cuando el ESP32 responde en vivo
                if (isRecordingData && viewModel.isLiveReceiving.value && now - lastRecordedTime >= 1000L) {
                    lastRecordedTime = now
                    appendCsvRow(record)
                }

                if (now - lastUiUpdateTime < 50 && record.alertLevel == lastNotifiedLevel) return@collectLatest
                lastUiUpdateTime = now

                stabilityGauge.setFactorOfSafety(record.factorOfSafety)
                slopeTwin3D.updateTelemetry(
                    record.tiltDeg,
                    record.dispMm,
                    record.soilMoisturePct,
                    record.forceN,
                    record.pgaMg,
                    record.alertLevel
                )

                tvMoisturePct.text = String.format("%.1f %%", record.soilMoisturePct)
                tvTiltDeg.text = String.format("%.2f °", record.tiltDeg)
                tvDispMm.text = String.format("%.1f mm", record.dispMm)
                tvForceN.text = String.format("%.2f N", record.forceN)

                sparkHum.push(record.soilMoisturePct)
                sparkTilt.push(record.tiltDeg)
                sparkDisp.push(record.dispMm)
                sparkForce.push(record.forceN)

                if (record.sensorWarnings.isNotEmpty() && viewModel.isLiveReceiving.value) {
                    tvSensorDiagnostics.visibility = View.VISIBLE
                    tvSensorDiagnostics.text = "⚠ " + record.sensorWarnings.joinToString(" · ")
                } else {
                    tvSensorDiagnostics.visibility = View.GONE
                }

                when (record.alertLevel) {
                    AlertLevel.CRITICAL -> {
                        tvAlarmLevel.text = "ALERTA CRÍTICA · EVACUAR"
                        tvAlarmLevel.setTextColor(Color.parseColor("#EF4444"))
                        tvActionAdvice.text = "Riesgo alto de deslizamiento (FS ${String.format("%.2f", record.factorOfSafety)}). Evacuar el sector."
                        triggerHazardAlarm(isCritical = true)
                        sendSystemNotification(
                            "ALERTA CRÍTICA DE TALUD (FS ${String.format("%.2f", record.factorOfSafety)})",
                            "Riesgo alto de deslizamiento. Humedad ${record.soilMoisturePct.toInt()}%, grieta ${String.format("%.1f", record.dispMm)} mm.",
                            AlertLevel.CRITICAL
                        )
                    }
                    AlertLevel.WARNING -> {
                        tvAlarmLevel.text = "PRECAUCIÓN · SATURACIÓN"
                        tvAlarmLevel.setTextColor(Color.parseColor("#F59E0B"))
                        tvActionAdvice.text = "Suelo saturado o movimiento detectado (FS ${String.format("%.2f", record.factorOfSafety)}). Vigilar talud."
                        triggerHazardAlarm(isCritical = false)
                        sendSystemNotification(
                            "PRECAUCIÓN EN TALUD (FS ${String.format("%.2f", record.factorOfSafety)})",
                            "Incremento de humedad (${record.soilMoisturePct.toInt()}%) o movimiento detectado.",
                            AlertLevel.WARNING
                        )
                    }
                    AlertLevel.STABLE -> {
                        tvAlarmLevel.text = "TERRENO SEGURO"
                        tvAlarmLevel.setTextColor(Color.parseColor("#10B981"))
                        tvActionAdvice.text = "Estabilidad óptima. Los 4 sensores reales están activos y estables."
                        lastNotifiedLevel = AlertLevel.STABLE
                    }
                }

                if (lastLoggedLevel != record.alertLevel) {
                    lastLoggedLevel = record.alertLevel
                    val stamp = timeFmt.format(Date())
                    val label = when (record.alertLevel) {
                        AlertLevel.CRITICAL -> "CRÍTICO"
                        AlertLevel.WARNING -> "PRECAUCIÓN"
                        AlertLevel.STABLE -> "ESTABLE"
                    }
                    eventLines.add(0, "[$stamp] $label — FS ${String.format("%.2f", record.factorOfSafety)} · Hum ${record.soilMoisturePct.toInt()}% · Grieta ${String.format("%.1f", record.dispMm)} mm")
                    if (eventLines.size > 15) eventLines.removeAt(eventLines.lastIndex)
                    tvEventLog.text = eventLines.joinToString("\n")
                }
            }
        }
    }

    private fun triggerHazardAlarm(isCritical: Boolean) {
        if (isAlarmMuted) return
        val now = System.currentTimeMillis()
        if (now - lastAlarmTime < (if (isCritical) 1400L else 4000L)) return
        lastAlarmTime = now

        val tone = if (isCritical) ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK else ToneGenerator.TONE_PROP_BEEP
        try {
            toneGenerator?.startTone(tone, if (isCritical) 220 else 100)
        } catch (_: Exception) {}

        val pattern = if (isCritical) longArrayOf(0, 220, 100, 220) else longArrayOf(0, 120)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(if (isCritical) 260L else 120L)
        }
    }

    private fun sendSystemNotification(title: String, body: String, level: AlertLevel, force: Boolean = false) {
        if (!force && lastNotifiedLevel == level) return
        if (!force) lastNotifiedLevel = level

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE)

        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(if (force) 1002 else 1001, notif)
    }

    private fun appendCsvRow(r: TelemetryRecord) {
        if (csvRows.size >= 15000) csvRows.removeAt(0)
        val ts = isoFmt.format(Date(r.timestampMs))
        val m = moments[momentIdx]
        val vibG = r.pgaMg / 1000f
        val st = when (r.alertLevel) {
            AlertLevel.CRITICAL -> "COLAPSO"
            AlertLevel.WARNING -> "PRECAUCION"
            AlertLevel.STABLE -> "SEGURO"
        }
        val row = String.format(
            Locale.US,
            "%s,%s,%d,%.2f,%d,%.2f,%d,%.1f,%d,%d,%d,%.2f,%.3f,%.2f,%s",
            ts, m, r.rawForce, r.forceN, r.rawIR, r.dispMm, r.rawSoil,
            r.soilMoisturePct, r.accX, r.accY, r.accZ, r.tiltDeg, vibG, r.factorOfSafety, st
        )
        csvRows.add(row)
        updateRecorderCounter()
    }

    private fun updateRecorderCounter() {
        val stateTxt = if (isRecordingData) "Grabando" else "Pausado"
        tvRecordedCount.text = "${csvRows.size} muestras reales · $stateTxt · ${moments[momentIdx]}"
    }

    private fun exportAndShareCsv() {
        if (csvRows.isEmpty()) {
            Toast.makeText(this, "Aún no hay muestras grabadas. Conecta el ESP32 por Wi-Fi primero.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val exportDir = File(cacheDir, "exports").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outFile = File(exportDir, "sat_geo_4_sensores_$stamp.csv")
            val header = "\uFEFFtimestamp,momento,raw_fsr,force_N,raw_ir,disp_mm,raw_soil,hum_pct,acc_x,acc_y,acc_z,tilt_deg,vib_g,FS,status\n"
            outFile.writeText(header + csvRows.joinToString("\n"), Charsets.UTF_8)

            val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", outFile)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "SAT-GEO Datos Reales 4 Sensores (${csvRows.size} muestras)")
                putExtra(Intent.EXTRA_TEXT, "Adjunto registro real de los 4 sensores (FSR-406, IR P/N 1102, Humedad, ADXL345) con ${csvRows.size} muestras.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Exportar datos CSV (Excel)"))
        } catch (e: Exception) {
            Toast.makeText(this, "Error al exportar CSV: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.disconnectHttp()
        toneGenerator?.release()
    }

    companion object {
        private const val CHANNEL_ID = "satgeo_alerts_v2"
    }
}
