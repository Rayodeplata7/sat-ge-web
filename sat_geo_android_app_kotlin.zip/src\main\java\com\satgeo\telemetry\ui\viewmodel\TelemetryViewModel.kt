package com.satgeo.telemetry.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.satgeo.telemetry.engine.GeomechanicalEngine
import com.satgeo.telemetry.engine.TelemetryRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class TelemetryViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = GeomechanicalEngine()

    private val _telemetryState = MutableStateFlow<TelemetryRecord?>(null)
    val telemetryState: StateFlow<TelemetryRecord?> = _telemetryState.asStateFlow()

    private val _isHttpConnected = MutableStateFlow(false)
    val isHttpConnected: StateFlow<Boolean> = _isHttpConnected.asStateFlow()

    private val _isLiveReceiving = MutableStateFlow(false)
    val isLiveReceiving: StateFlow<Boolean> = _isLiveReceiving.asStateFlow()

    private val _connectionStatus = MutableStateFlow("Buscando ESP32 Wi-Fi (192.168.4.1)...")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private var httpJob: Job? = null

    init {
        // 100% sensores reales por Wi-Fi (cero simulador, cero USB)
        connectHttpEndpoint("192.168.4.1", "Wi-Fi ESP32")
    }

    fun calibrateZero() {
        engine.calibrateZero()
    }

    fun onHardwarePacket(
        rawForce: Int,
        rawIR: Int,
        rawSoil: Int,
        accX: Int,
        accY: Int,
        accZ: Int
    ) {
        val record = engine.processSample(
            System.currentTimeMillis(),
            rawForce,
            rawIR,
            rawSoil,
            accX,
            accY,
            accZ
        )
        _telemetryState.value = record
    }

    fun connectHttpEndpoint(baseUrl: String, label: String) {
        httpJob?.cancel()
        engine.resetZero()
        _isHttpConnected.value = true
        _isLiveReceiving.value = false
        _connectionStatus.value = "Conectando a $label..."

        val cleanUrl = baseUrl.trim().removeSuffix("/")
        val target = if (cleanUrl.startsWith("http")) "$cleanUrl/api/telemetry" else "http://$cleanUrl/api/telemetry"
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        httpJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive && _isHttpConnected.value) {
                var conn: HttpURLConnection? = null
                try {
                    val wifiNet: Network? = cm.allNetworks.firstOrNull { net ->
                        val caps = cm.getNetworkCapabilities(net)
                        caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    }
                    val url = URL(target)
                    conn = ((wifiNet?.openConnection(url) ?: url.openConnection()) as HttpURLConnection).apply {
                        connectTimeout = 1000
                        readTimeout = 1000
                        requestMethod = "GET"
                    }
                    if (conn.responseCode == 200) {
                        val body = conn.inputStream.bufferedReader().use { it.readText() }
                        val json = JSONObject(body)
                        // Si se conecta al servidor PC y el ESP32 está desconectado, no emitir datos falsos
                        if (json.has("serial_connected") && !json.optBoolean("serial_connected", true)) {
                            _isLiveReceiving.value = false
                            _connectionStatus.value = "$label · Esperando ESP32"
                        } else if (json.has("raw_fsr") && json.has("raw_ir") && json.has("raw_soil")) {
                            _isLiveReceiving.value = true
                            _connectionStatus.value = "$label · Sensores en Vivo"
                            onHardwarePacket(
                                json.getInt("raw_fsr"),
                                json.getInt("raw_ir"),
                                json.getInt("raw_soil"),
                                json.optInt("acc_x", 0),
                                json.optInt("acc_y", 0),
                                json.optInt("acc_z", 256)
                            )
                        }
                    } else {
                        _isLiveReceiving.value = false
                        _connectionStatus.value = "Sin respuesta de $label"
                    }
                } catch (_: Exception) {
                    _isLiveReceiving.value = false
                    _connectionStatus.value = "Buscando $label..."
                } finally {
                    try { conn?.disconnect() } catch (_: Exception) {}
                }
                delay(75)
            }
        }
    }

    fun disconnectHttp() {
        _isHttpConnected.value = false
        _isLiveReceiving.value = false
        httpJob?.cancel()
        _connectionStatus.value = "Wi-Fi desconectado · Conecta a 192.168.4.1"
    }

    override fun onCleared() {
        super.onCleared()
        httpJob?.cancel()
    }
}
