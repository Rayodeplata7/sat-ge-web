package com.satgeo.telemetry.ui.view

import android.content.Context
import android.graphics.*
import android.os.Build
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView

/**
 * SAT-GEO 4.0 - Live 4-Sensor Oscilloscope SurfaceView
 * Renders real-time normalized waveforms for FSR-406, IR P/N 1102, Soil Moisture, and ADXL345 (Tilt + Vib).
 */
class TelemetrySurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    private var renderThread: Thread? = null
    @Volatile private var isRunning = false

    private val capacity = 300
    private val bufFsr = FloatArray(capacity)
    private val bufIr = FloatArray(capacity)
    private val bufHum = FloatArray(capacity)
    private val bufTilt = FloatArray(capacity)
    private val bufVib = FloatArray(capacity)
    private var head = 0
    private var sampleCount = 0

    private var lastFsr = 0f
    private var lastIr = 0f
    private var lastHum = 8f
    private var lastTilt = 0f
    private var lastVib = 0f

    private val density = resources.displayMetrics.density

    private val bgPaint = Paint().apply { color = Color.parseColor("#04070E") }
    private val legendBgPaint = Paint().apply { color = Color.parseColor("#E6070C16") }
    private val gridPaint = Paint().apply {
        color = Color.parseColor("#152238")
        strokeWidth = 1.2f
        style = Paint.Style.STROKE
    }
    private val triggerPaint = Paint().apply {
        color = Color.parseColor("#66FF0055")
        strokeWidth = 1.5f
        pathEffect = DashPathEffect(floatArrayOf(12f, 12f), 0f)
        style = Paint.Style.STROKE
    }

    private val fsrPaint = makeTracePaint("#10B981", 3.0f)
    private val irPaint = makeTracePaint("#00F0FF", 2.8f)
    private val humPaint = makeTracePaint("#38BDF8", 2.8f)
    private val tiltPaint = makeTracePaint("#F59E0B", 3.0f)
    private val vibPaint = makeTracePaint("#F43F5E", 2.2f)

    private val legendTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 10.5f * density
        isFakeBoldText = true
    }

    private val pathFsr = Path()
    private val pathIr = Path()
    private val pathHum = Path()
    private val pathTilt = Path()
    private val pathVib = Path()

    private fun makeTracePaint(hex: String, stroke: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor(hex)
        strokeWidth = stroke
        style = Paint.Style.STROKE
    }

    init {
        holder.addCallback(this)
    }

    @Synchronized
    fun pushSample(forceN: Float, dispMm: Float, moisturePct: Float, tiltDeg: Float, pgaMg: Float) {
        bufFsr[head] = (forceN / 4.4f).coerceIn(0f, 1f)
        bufIr[head] = (dispMm / 30.0f).coerceIn(0f, 1f)
        bufHum[head] = (moisturePct / 100.0f).coerceIn(0f, 1f)
        bufTilt[head] = (tiltDeg / 18.0f).coerceIn(0f, 1f)
        bufVib[head] = (pgaMg / 350.0f).coerceIn(0f, 1f)

        lastFsr = forceN
        lastIr = dispMm
        lastHum = moisturePct
        lastTilt = tiltDeg
        lastVib = pgaMg

        head = (head + 1) % capacity
        if (sampleCount < capacity) sampleCount++
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        isRunning = true
        renderThread = Thread(this, "TelemetryScopeRender").apply { start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        isRunning = false
        try {
            renderThread?.join(500)
        } catch (_: InterruptedException) {}
    }

    override fun run() {
        while (isRunning) {
            if (!holder.surface.isValid) {
                try { Thread.sleep(32) } catch (_: InterruptedException) { break }
                continue
            }
            var canvas: Canvas? = null
            try {
                canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    holder.lockHardwareCanvas()
                } else {
                    holder.lockCanvas()
                }
                if (canvas != null) drawScope(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
                }
            }
            try { Thread.sleep(20) } catch (_: InterruptedException) { break }
        }
    }

    private fun drawScope(canvas: Canvas) {
        val w = canvas.width.toFloat()
        val h = canvas.height.toFloat()
        val legendH = 42f * density
        val plotTop = legendH + 6f
        val plotBottom = h - 10f
        val plotH = (plotBottom - plotTop).coerceAtLeast(20f)

        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // Reticle grid
        val divX = w / 10f
        for (i in 0..10) canvas.drawLine(i * divX, plotTop, i * divX, plotBottom, gridPaint)
        for (i in 0..4) {
            val y = plotTop + (i / 4f) * plotH
            canvas.drawLine(0f, y, w, y, gridPaint)
        }

        // 70% alert reference line
        val trigY = plotBottom - 0.70f * plotH
        canvas.drawLine(0f, trigY, w, trigY, triggerPaint)

        synchronized(this) {
            if (sampleCount >= 2) {
                val dx = w / (capacity - 1).toFloat()
                pathFsr.reset(); pathIr.reset(); pathHum.reset(); pathTilt.reset(); pathVib.reset()
                for (i in 0 until sampleCount) {
                    val idx = (head - sampleCount + i + capacity) % capacity
                    val x = i * dx
                    val yFsr = plotBottom - bufFsr[idx] * plotH
                    val yIr = plotBottom - bufIr[idx] * plotH
                    val yHum = plotBottom - bufHum[idx] * plotH
                    val yTilt = plotBottom - bufTilt[idx] * plotH
                    val yVib = plotBottom - bufVib[idx] * plotH
                    if (i == 0) {
                        pathFsr.moveTo(x, yFsr); pathIr.moveTo(x, yIr); pathHum.moveTo(x, yHum)
                        pathTilt.moveTo(x, yTilt); pathVib.moveTo(x, yVib)
                    } else {
                        pathFsr.lineTo(x, yFsr); pathIr.lineTo(x, yIr); pathHum.lineTo(x, yHum)
                        pathTilt.lineTo(x, yTilt); pathVib.lineTo(x, yVib)
                    }
                }
                canvas.drawPath(pathHum, humPaint)
                canvas.drawPath(pathIr, irPaint)
                canvas.drawPath(pathFsr, fsrPaint)
                canvas.drawPath(pathTilt, tiltPaint)
                canvas.drawPath(pathVib, vibPaint)
            }

            // Top 2-row Legend with live values for all 4 sensors
            canvas.drawRect(0f, 0f, w, legendH, legendBgPaint)
            val padX = 10f * density
            val midX = w * 0.50f
            val row1Y = 16f * density
            val row2Y = 34f * density

            legendTextPaint.color = Color.parseColor("#10B981")
            canvas.drawText("● FSR: ${String.format("%.2f", lastFsr)} N", padX, row1Y, legendTextPaint)

            legendTextPaint.color = Color.parseColor("#00F0FF")
            canvas.drawText("● IR: ${String.format("%.1f", lastIr)} mm", midX, row1Y, legendTextPaint)

            legendTextPaint.color = Color.parseColor("#38BDF8")
            canvas.drawText("● HUM: ${lastHum.toInt()}%", padX, row2Y, legendTextPaint)

            legendTextPaint.color = Color.parseColor("#F59E0B")
            canvas.drawText("● ADXL: ${String.format("%.1f", lastTilt)}° · ${lastVib.toInt()}mg", midX, row2Y, legendTextPaint)
        }
    }
}
