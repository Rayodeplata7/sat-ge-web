package com.satgeo.telemetry.ui.view

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView

/**
 * SAT-GEO 4.0 - Ultra-Fast Dual-Channel Oscilloscope SurfaceView
 * Renders 250 Hz continuous waveforms with zero memory allocations inside the draw loop.
 */
class TelemetrySurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    private var renderThread: Thread? = null
    private var isRunning = false

    private val capacity = 500
    private val bufferCH1 = FloatArray(capacity)
    private val bufferCH2 = FloatArray(capacity)
    private var head = 0
    private var sampleCount = 0

    // Reusable Paints to prevent Garbage Collector pauses
    private val bgPaint = Paint().apply { color = Color.parseColor("#04070E") }
    private val gridPaint = Paint().apply {
        color = Color.parseColor("#152238")
        strokeWidth = 1.5f
        style = Paint.Style.STROKE
    }
    private val triggerPaint = Paint().apply {
        color = Color.parseColor("#FF0055")
        strokeWidth = 2.0f
        pathEffect = DashPathEffect(floatArrayOf(15f, 15f), 0f)
        style = Paint.Style.STROKE
    }
    private val ch1Paint = Paint().apply {
        color = Color.parseColor("#00F0FF")
        strokeWidth = 3.5f
        isAntiAlias = true
        style = Paint.Style.STROKE
        setShadowLayer(8f, 0f, 0f, Color.parseColor("#00F0FF"))
    }
    private val ch2Paint = Paint().apply {
        color = Color.parseColor("#FFB800")
        strokeWidth = 2.8f
        isAntiAlias = true
        style = Paint.Style.STROKE
        setShadowLayer(6f, 0f, 0f, Color.parseColor("#FFB800"))
    }

    private val pathCH1 = Path()
    private val pathCH2 = Path()

    init {
        holder.addCallback(this)
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    @Synchronized
    fun pushSample(forceN: Float, distCm: Float) {
        bufferCH1[head] = forceN
        bufferCH2[head] = distCm
        head = (head + 1) % capacity
        if (sampleCount < capacity) sampleCount++
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        isRunning = true
        renderThread = Thread(this, "TelemetryScopeRender").apply { start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        isRunning = false
        var retry = true
        while (retry) {
            try {
                renderThread?.join()
                retry = false
            } catch (e: InterruptedException) {
                // Retry
            }
        }
    }

    override fun run() {
        while (isRunning) {
            val canvas = holder.lockHardwareCanvas() ?: continue
            try {
                drawScope(canvas)
            } finally {
                holder.unlockCanvasAndPost(canvas)
            }

            try {
                Thread.sleep(16) // ~60 FPS smooth render loop
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    private fun drawScope(canvas: Canvas) {
        val w = canvas.width.toFloat()
        val h = canvas.height.toFloat()

        // 1. Clear background
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // 2. Reticle Grid (10 horizontal, 6 vertical divisions)
        val divX = w / 10f
        val divY = h / 6f
        for (i in 0..10) {
            val x = i * divX
            canvas.drawLine(x, 0f, x, h, gridPaint)
        }
        for (i in 0..6) {
            val y = i * divY
            canvas.drawLine(0f, y, w, y, gridPaint)
        }

        // 3. Trigger Line: 3.5 N critical threshold
        val triggerY = h - (3.5f / 5.0f) * (h - 40f) - 20f
        canvas.drawLine(0f, triggerY, w, triggerY, triggerPaint)

        // 4. Waveforms
        synchronized(this) {
            if (sampleCount < 2) return

            val dx = w / (capacity - 1).toFloat()
            pathCH1.reset()
            pathCH2.reset()

            for (i in 0 until sampleCount) {
                val idx = (head - sampleCount + i + capacity) % capacity
                val x = i * dx

                val fVal = bufferCH1[idx]
                val y1 = h - (fVal / 5.0f) * (h - 40f) - 20f
                if (i == 0) pathCH1.moveTo(x, y1) else pathCH1.lineTo(x, y1)

                val irVal = bufferCH2[idx]
                val y2 = h - (irVal / 5.0f) * (h - 40f) - 20f
                if (i == 0) pathCH2.moveTo(x, y2) else pathCH2.lineTo(x, y2)
            }

            canvas.drawPath(pathCH1, ch1Paint)
            canvas.drawPath(pathCH2, ch2Paint)
        }
    }
}
